# Digital VLSI Design – HW3

**Course:** 83-612 – Digital VLSI Design ; 
**Year:** 2025–26

## Overview

This repository contains the full three-part mini-project for Homework 3 of the Digital VLSI Design course.
The assignment guides the student through the **complete front-end digital design flow**, from **RTL design and simulation** to **synthesis, gate-level simulation**, and **power estimation**.

## Instructions
As always the full instructions are under the `docs/` folder and in the course's Discord server. Below is just a brief overview of the tasks to be completed. Go over the documentation for detailed steps, hints, and requirements.

---

## 🧩 Part 1 – RTL Design and Simulation

* **Goal:** Design and verify an `Average` unit that computes the mean of a series of input values.
* **Tasks:**

  * Implement a synthesizable RTL module (`Average.v`) with a given interface.
  * Develop and improve the provided testbench (`average_tb.sv`).
  * Simulate using *Cadence Xcelium* (`irun` / `xrun`) and verify correct functionality.

---

## ⚙️ Part 2 – Synthesis

* **Goal:** Synthesize the RTL design using *Cadence Genus*.
* **Steps:**

  1. Prepare project directories (`src`, `inputs`, `scripts`, `reports`, `exports`).
  2. Set up design constraints (`.sdc`) and parameterized `.defines` file.
  3. Run synthesis via `scripts/genus.tcl`.
  4. Analyze timing, area, and cell usage.

---

## 🔍 Part 3 – Gate-Level Simulation & Power Estimation

* **Goal:** Verify and evaluate the synthesized design at gate level and estimate power.
* **Tasks:**

  1. **Gate-Level Simulation (GLV):**

     * Run zero-delay GLV (`xrun_options.glv`)
     * Perform SDF back-annotated simulation (`xrun_options.backannotation`)
  2. **Power Estimation:**

     * Generate switching activity (`.vcd`)
     * Run *Cadence Voltus* (`voltus.post_synth.tcl`)
     * Review power reports in `export/pwr/power.rpt`

---


## 📝 Submission

Commit and push your results to your personal branch named after your **student ID**:

```bash
git add <files>
git commit -m "HW3 completed – synthesis + power results"
git push origin <ID_number>
```
