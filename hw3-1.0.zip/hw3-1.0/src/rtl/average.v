`timescale  1ns/1ps

module average #(
    parameter NOF_BITS = 32,
    parameter WIDTH = 32
) (
    input wire clk,
    input wire rst_n,
    input wire start,
    input wire data_first,
    input wire data_last,
    input wire [NOF_BITS-1:0] data_in,
    output reg [NOF_BITS:0] data_out,
    output reg busy,    
    output reg TO,
    output reg done    
);


    // use this divider for the average calculation 
    divu_int #(NOF_BITS+1) div ( 
        .clk(),              
        .rst_n(),              
        .start(), // each time this signal is high the run starts again         
        .busy(), // busy=1 -  the result isn't ready 
        .done(), // this signal is high for only one cycle             
        .valid(), // valid result signal
        .dbz(), // divide by zero signal
        .a(), // input
        .b(), // divider
        .val(), // result
        .rem() // reminder
    );

endmodule
