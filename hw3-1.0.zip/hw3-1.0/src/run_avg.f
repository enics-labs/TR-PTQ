# rtl
# WRITE HERE YOUR DESIGN NAMES
../src/rtl/div.sv
#test bench
../src/tb/average_tb.sv
-sv
