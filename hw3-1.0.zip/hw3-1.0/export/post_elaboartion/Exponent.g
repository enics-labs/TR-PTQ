######################################################################

# Created by Genus(TM) Synthesis Solution 21.15-s080_1 on Tue Oct 24 19:18:15 UTC 2023

# This file contains the Genus script for design:Exponent

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {/data/tsmc/65LP/dig_libs/ARM_FEONLY/arm/tsmc/cln65lp//sc9_base_rvt/r0p0/lib/ /data/tsmc/65LP/dig_libs/ARM_FEONLY/arm/tsmc/cln65lp//sc9_base_lvt/r0p0/lib/ /data/tsmc/65LP/dig_libs/ARM_FEONLY/arm/tsmc/cln65lp//sc9_base_hvt/r0p0/lib/}
set_db -quiet design_mode_process no_value
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet lp_insert_clock_gating true
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet hdl_language sv
set_db -quiet tinfo_tstamp_file .rs_levyeli6.tstamp
set_db -quiet metric_enable true
set_db -quiet design_process_node 65
set_db -quiet route_design_with_via_in_pin true
set_db -quiet hdl_track_filename_row_col true
set_db -quiet flow_metrics_snapshot_uuid e367cd02-eeb9-44fb-859e-917654a7dd06
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet interconnect_mode wireload
set_db -quiet wireload_mode top
set_db -quiet lib_cell:default_emulate_libset_max/sc9_cln65lp_base_rvt_ss_typical_max_0p90v_125c/INV_X0P5B_A9TR .avoid true
set_db -quiet wireload_selection none
set_db -quiet operating_condition:default_emulate_libset_max/sc9_cln65lp_base_rvt_ss_typical_max_0p90v_125c/ss_typical_max_0p90v_125c .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/sc9_cln65lp_base_rvt_ss_typical_max_0p90v_125c/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/sc9_cln65lp_base_lvt_ss_typical_max_0p90v_125c/ss_typical_max_0p90v_125c .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/sc9_cln65lp_base_lvt_ss_typical_max_0p90v_125c/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/sc9_cln65lp_base_hvt_ss_typical_max_0p90v_125c/ss_typical_max_0p90v_125c .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/sc9_cln65lp_base_hvt_ss_typical_max_0p90v_125c/_nominal_ .tree_type balanced_tree
# BEGIN MSV SECTION
# END MSV SECTION
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:Exponent .seq_reason_deleted_internal {}
set_db -quiet design:Exponent .seq_mbci_coverage 0.0
set_db -quiet design:Exponent .hdl_user_name Exponent
set_db -quiet design:Exponent .hdl_filelist {{default {-sv -f} {SYNTHESIS} {/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/../dut_src_list.txt} {} {}}}
set_db -quiet design:Exponent .verification_directory fv/Exponent
set_db -quiet design:Exponent .arch_filename /data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v
set_db -quiet design:Exponent .entity_filename /data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v
set_db -quiet port:Exponent/clk .original_name clk
set_db -quiet port:Exponent/rst_n .original_name rst_n
set_db -quiet port:Exponent/start .original_name start
set_db -quiet {port:Exponent/i_prec[3]} .original_name {i_prec[3]}
set_db -quiet {port:Exponent/i_prec[2]} .original_name {i_prec[2]}
set_db -quiet {port:Exponent/i_prec[1]} .original_name {i_prec[1]}
set_db -quiet {port:Exponent/i_prec[0]} .original_name {i_prec[0]}
set_db -quiet {port:Exponent/data_in[31]} .original_name {data_in[31]}
set_db -quiet {port:Exponent/data_in[30]} .original_name {data_in[30]}
set_db -quiet {port:Exponent/data_in[29]} .original_name {data_in[29]}
set_db -quiet {port:Exponent/data_in[28]} .original_name {data_in[28]}
set_db -quiet {port:Exponent/data_in[27]} .original_name {data_in[27]}
set_db -quiet {port:Exponent/data_in[26]} .original_name {data_in[26]}
set_db -quiet {port:Exponent/data_in[25]} .original_name {data_in[25]}
set_db -quiet {port:Exponent/data_in[24]} .original_name {data_in[24]}
set_db -quiet {port:Exponent/data_in[23]} .original_name {data_in[23]}
set_db -quiet {port:Exponent/data_in[22]} .original_name {data_in[22]}
set_db -quiet {port:Exponent/data_in[21]} .original_name {data_in[21]}
set_db -quiet {port:Exponent/data_in[20]} .original_name {data_in[20]}
set_db -quiet {port:Exponent/data_in[19]} .original_name {data_in[19]}
set_db -quiet {port:Exponent/data_in[18]} .original_name {data_in[18]}
set_db -quiet {port:Exponent/data_in[17]} .original_name {data_in[17]}
set_db -quiet {port:Exponent/data_in[16]} .original_name {data_in[16]}
set_db -quiet {port:Exponent/data_in[15]} .original_name {data_in[15]}
set_db -quiet {port:Exponent/data_in[14]} .original_name {data_in[14]}
set_db -quiet {port:Exponent/data_in[13]} .original_name {data_in[13]}
set_db -quiet {port:Exponent/data_in[12]} .original_name {data_in[12]}
set_db -quiet {port:Exponent/data_in[11]} .original_name {data_in[11]}
set_db -quiet {port:Exponent/data_in[10]} .original_name {data_in[10]}
set_db -quiet {port:Exponent/data_in[9]} .original_name {data_in[9]}
set_db -quiet {port:Exponent/data_in[8]} .original_name {data_in[8]}
set_db -quiet {port:Exponent/data_in[7]} .original_name {data_in[7]}
set_db -quiet {port:Exponent/data_in[6]} .original_name {data_in[6]}
set_db -quiet {port:Exponent/data_in[5]} .original_name {data_in[5]}
set_db -quiet {port:Exponent/data_in[4]} .original_name {data_in[4]}
set_db -quiet {port:Exponent/data_in[3]} .original_name {data_in[3]}
set_db -quiet {port:Exponent/data_in[2]} .original_name {data_in[2]}
set_db -quiet {port:Exponent/data_in[1]} .original_name {data_in[1]}
set_db -quiet {port:Exponent/data_in[0]} .original_name {data_in[0]}
set_db -quiet {port:Exponent/data_out[63]} .original_name {data_out[63]}
set_db -quiet {port:Exponent/data_out[62]} .original_name {data_out[62]}
set_db -quiet {port:Exponent/data_out[61]} .original_name {data_out[61]}
set_db -quiet {port:Exponent/data_out[60]} .original_name {data_out[60]}
set_db -quiet {port:Exponent/data_out[59]} .original_name {data_out[59]}
set_db -quiet {port:Exponent/data_out[58]} .original_name {data_out[58]}
set_db -quiet {port:Exponent/data_out[57]} .original_name {data_out[57]}
set_db -quiet {port:Exponent/data_out[56]} .original_name {data_out[56]}
set_db -quiet {port:Exponent/data_out[55]} .original_name {data_out[55]}
set_db -quiet {port:Exponent/data_out[54]} .original_name {data_out[54]}
set_db -quiet {port:Exponent/data_out[53]} .original_name {data_out[53]}
set_db -quiet {port:Exponent/data_out[52]} .original_name {data_out[52]}
set_db -quiet {port:Exponent/data_out[51]} .original_name {data_out[51]}
set_db -quiet {port:Exponent/data_out[50]} .original_name {data_out[50]}
set_db -quiet {port:Exponent/data_out[49]} .original_name {data_out[49]}
set_db -quiet {port:Exponent/data_out[48]} .original_name {data_out[48]}
set_db -quiet {port:Exponent/data_out[47]} .original_name {data_out[47]}
set_db -quiet {port:Exponent/data_out[46]} .original_name {data_out[46]}
set_db -quiet {port:Exponent/data_out[45]} .original_name {data_out[45]}
set_db -quiet {port:Exponent/data_out[44]} .original_name {data_out[44]}
set_db -quiet {port:Exponent/data_out[43]} .original_name {data_out[43]}
set_db -quiet {port:Exponent/data_out[42]} .original_name {data_out[42]}
set_db -quiet {port:Exponent/data_out[41]} .original_name {data_out[41]}
set_db -quiet {port:Exponent/data_out[40]} .original_name {data_out[40]}
set_db -quiet {port:Exponent/data_out[39]} .original_name {data_out[39]}
set_db -quiet {port:Exponent/data_out[38]} .original_name {data_out[38]}
set_db -quiet {port:Exponent/data_out[37]} .original_name {data_out[37]}
set_db -quiet {port:Exponent/data_out[36]} .original_name {data_out[36]}
set_db -quiet {port:Exponent/data_out[35]} .original_name {data_out[35]}
set_db -quiet {port:Exponent/data_out[34]} .original_name {data_out[34]}
set_db -quiet {port:Exponent/data_out[33]} .original_name {data_out[33]}
set_db -quiet {port:Exponent/data_out[32]} .original_name {data_out[32]}
set_db -quiet {port:Exponent/data_out[31]} .original_name {data_out[31]}
set_db -quiet {port:Exponent/data_out[30]} .original_name {data_out[30]}
set_db -quiet {port:Exponent/data_out[29]} .original_name {data_out[29]}
set_db -quiet {port:Exponent/data_out[28]} .original_name {data_out[28]}
set_db -quiet {port:Exponent/data_out[27]} .original_name {data_out[27]}
set_db -quiet {port:Exponent/data_out[26]} .original_name {data_out[26]}
set_db -quiet {port:Exponent/data_out[25]} .original_name {data_out[25]}
set_db -quiet {port:Exponent/data_out[24]} .original_name {data_out[24]}
set_db -quiet {port:Exponent/data_out[23]} .original_name {data_out[23]}
set_db -quiet {port:Exponent/data_out[22]} .original_name {data_out[22]}
set_db -quiet {port:Exponent/data_out[21]} .original_name {data_out[21]}
set_db -quiet {port:Exponent/data_out[20]} .original_name {data_out[20]}
set_db -quiet {port:Exponent/data_out[19]} .original_name {data_out[19]}
set_db -quiet {port:Exponent/data_out[18]} .original_name {data_out[18]}
set_db -quiet {port:Exponent/data_out[17]} .original_name {data_out[17]}
set_db -quiet {port:Exponent/data_out[16]} .original_name {data_out[16]}
set_db -quiet {port:Exponent/data_out[15]} .original_name {data_out[15]}
set_db -quiet {port:Exponent/data_out[14]} .original_name {data_out[14]}
set_db -quiet {port:Exponent/data_out[13]} .original_name {data_out[13]}
set_db -quiet {port:Exponent/data_out[12]} .original_name {data_out[12]}
set_db -quiet {port:Exponent/data_out[11]} .original_name {data_out[11]}
set_db -quiet {port:Exponent/data_out[10]} .original_name {data_out[10]}
set_db -quiet {port:Exponent/data_out[9]} .original_name {data_out[9]}
set_db -quiet {port:Exponent/data_out[8]} .original_name {data_out[8]}
set_db -quiet {port:Exponent/data_out[7]} .original_name {data_out[7]}
set_db -quiet {port:Exponent/data_out[6]} .original_name {data_out[6]}
set_db -quiet {port:Exponent/data_out[5]} .original_name {data_out[5]}
set_db -quiet {port:Exponent/data_out[4]} .original_name {data_out[4]}
set_db -quiet {port:Exponent/data_out[3]} .original_name {data_out[3]}
set_db -quiet {port:Exponent/data_out[2]} .original_name {data_out[2]}
set_db -quiet {port:Exponent/data_out[1]} .original_name {data_out[1]}
set_db -quiet {port:Exponent/data_out[0]} .original_name {data_out[0]}
set_db -quiet port:Exponent/busy .original_name busy
set_db -quiet port:Exponent/done .original_name done
set_db -quiet module:Exponent/divu_int_WIDTH32 .hdl_user_name divu_int
set_db -quiet module:Exponent/divu_int_WIDTH32 .hdl_filelist {{default {-sv -f} {SYNTHESIS} {/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/../dut_src_list.txt} {} {}}}
set_db -quiet module:Exponent/divu_int_WIDTH32 .arch_filename /data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv
set_db -quiet module:Exponent/divu_int_WIDTH32 .entity_filename /data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv
set_db -quiet module:Exponent/equal_unsigned .logical_hier false
set_db -quiet hinst:Exponent/div/eq_44_23 .rtlop_info {{} 0 0 0 3 0 63 0 2 1 1 0}
set_db -quiet module:Exponent/geq_unsigned .logical_hier false
set_db -quiet hinst:Exponent/div/gte_22_17 .rtlop_info {{} 0 0 0 3 0 122 0 2 1 1 0}
set_db -quiet module:Exponent/sub_unsigned .logical_hier false
set_db -quiet hinst:Exponent/div/sub_23_28 .rtlop_info {{} 0 0 0 3 0 9 0 2 1 1 0}
set_db -quiet module:Exponent/add_unsigned .logical_hier false
set_db -quiet hinst:Exponent/div/add_62_28 .rtlop_info {{} 0 0 0 3 0 7 0 2 1 1 0}
set_db -quiet module:Exponent/bmux .logical_hier false
set_db -quiet module:Exponent/bmux_3 .logical_hier false
set_db -quiet module:Exponent/bmux_16 .logical_hier false
set_db -quiet module:Exponent/bmux_18 .logical_hier false
set_db -quiet inst:Exponent/div/busy_reg .original_name div/busy
set_db -quiet inst:Exponent/div/busy_reg .orig_hdl_instantiated false
set_db -quiet inst:Exponent/div/busy_reg .single_bit_orig_name div/busy
set_db -quiet inst:Exponent/div/busy_reg .gint_phase_inversion false
set_db -quiet pin:Exponent/div/busy_reg/q .original_name div/busy/q
set_db -quiet inst:Exponent/div/done_reg .original_name div/done
set_db -quiet inst:Exponent/div/done_reg .orig_hdl_instantiated false
set_db -quiet inst:Exponent/div/done_reg .single_bit_orig_name div/done
set_db -quiet inst:Exponent/div/done_reg .gint_phase_inversion false
set_db -quiet pin:Exponent/div/done_reg/q .original_name div/done/q
set_db -quiet inst:Exponent/div/valid_reg .original_name div/valid
set_db -quiet inst:Exponent/div/valid_reg .orig_hdl_instantiated false
set_db -quiet inst:Exponent/div/valid_reg .single_bit_orig_name div/valid
set_db -quiet inst:Exponent/div/valid_reg .gint_phase_inversion false
set_db -quiet pin:Exponent/div/valid_reg/q .original_name div/valid/q
set_db -quiet inst:Exponent/div/dbz_reg .original_name div/dbz
set_db -quiet inst:Exponent/div/dbz_reg .orig_hdl_instantiated false
set_db -quiet inst:Exponent/div/dbz_reg .single_bit_orig_name div/dbz
set_db -quiet inst:Exponent/div/dbz_reg .gint_phase_inversion false
set_db -quiet pin:Exponent/div/dbz_reg/q .original_name div/dbz/q
set_db -quiet {inst:Exponent/div/val_reg[0]} .original_name {{div/val[0]}}
set_db -quiet {inst:Exponent/div/val_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[0]} .single_bit_orig_name {div/val[0]}
set_db -quiet {inst:Exponent/div/val_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[0]/q} .original_name {div/val[0]/q}
set_db -quiet {inst:Exponent/div/val_reg[1]} .original_name {{div/val[1]}}
set_db -quiet {inst:Exponent/div/val_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[1]} .single_bit_orig_name {div/val[1]}
set_db -quiet {inst:Exponent/div/val_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[1]/q} .original_name {div/val[1]/q}
set_db -quiet {inst:Exponent/div/val_reg[2]} .original_name {{div/val[2]}}
set_db -quiet {inst:Exponent/div/val_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[2]} .single_bit_orig_name {div/val[2]}
set_db -quiet {inst:Exponent/div/val_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[2]/q} .original_name {div/val[2]/q}
set_db -quiet {inst:Exponent/div/val_reg[3]} .original_name {{div/val[3]}}
set_db -quiet {inst:Exponent/div/val_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[3]} .single_bit_orig_name {div/val[3]}
set_db -quiet {inst:Exponent/div/val_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[3]/q} .original_name {div/val[3]/q}
set_db -quiet {inst:Exponent/div/val_reg[4]} .original_name {{div/val[4]}}
set_db -quiet {inst:Exponent/div/val_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[4]} .single_bit_orig_name {div/val[4]}
set_db -quiet {inst:Exponent/div/val_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[4]/q} .original_name {div/val[4]/q}
set_db -quiet {inst:Exponent/div/val_reg[5]} .original_name {{div/val[5]}}
set_db -quiet {inst:Exponent/div/val_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[5]} .single_bit_orig_name {div/val[5]}
set_db -quiet {inst:Exponent/div/val_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[5]/q} .original_name {div/val[5]/q}
set_db -quiet {inst:Exponent/div/val_reg[6]} .original_name {{div/val[6]}}
set_db -quiet {inst:Exponent/div/val_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[6]} .single_bit_orig_name {div/val[6]}
set_db -quiet {inst:Exponent/div/val_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[6]/q} .original_name {div/val[6]/q}
set_db -quiet {inst:Exponent/div/val_reg[7]} .original_name {{div/val[7]}}
set_db -quiet {inst:Exponent/div/val_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[7]} .single_bit_orig_name {div/val[7]}
set_db -quiet {inst:Exponent/div/val_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[7]/q} .original_name {div/val[7]/q}
set_db -quiet {inst:Exponent/div/val_reg[8]} .original_name {{div/val[8]}}
set_db -quiet {inst:Exponent/div/val_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[8]} .single_bit_orig_name {div/val[8]}
set_db -quiet {inst:Exponent/div/val_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[8]/q} .original_name {div/val[8]/q}
set_db -quiet {inst:Exponent/div/val_reg[9]} .original_name {{div/val[9]}}
set_db -quiet {inst:Exponent/div/val_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[9]} .single_bit_orig_name {div/val[9]}
set_db -quiet {inst:Exponent/div/val_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[9]/q} .original_name {div/val[9]/q}
set_db -quiet {inst:Exponent/div/val_reg[10]} .original_name {{div/val[10]}}
set_db -quiet {inst:Exponent/div/val_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[10]} .single_bit_orig_name {div/val[10]}
set_db -quiet {inst:Exponent/div/val_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[10]/q} .original_name {div/val[10]/q}
set_db -quiet {inst:Exponent/div/val_reg[11]} .original_name {{div/val[11]}}
set_db -quiet {inst:Exponent/div/val_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[11]} .single_bit_orig_name {div/val[11]}
set_db -quiet {inst:Exponent/div/val_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[11]/q} .original_name {div/val[11]/q}
set_db -quiet {inst:Exponent/div/val_reg[12]} .original_name {{div/val[12]}}
set_db -quiet {inst:Exponent/div/val_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[12]} .single_bit_orig_name {div/val[12]}
set_db -quiet {inst:Exponent/div/val_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[12]/q} .original_name {div/val[12]/q}
set_db -quiet {inst:Exponent/div/val_reg[13]} .original_name {{div/val[13]}}
set_db -quiet {inst:Exponent/div/val_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[13]} .single_bit_orig_name {div/val[13]}
set_db -quiet {inst:Exponent/div/val_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[13]/q} .original_name {div/val[13]/q}
set_db -quiet {inst:Exponent/div/val_reg[14]} .original_name {{div/val[14]}}
set_db -quiet {inst:Exponent/div/val_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[14]} .single_bit_orig_name {div/val[14]}
set_db -quiet {inst:Exponent/div/val_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[14]/q} .original_name {div/val[14]/q}
set_db -quiet {inst:Exponent/div/val_reg[15]} .original_name {{div/val[15]}}
set_db -quiet {inst:Exponent/div/val_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[15]} .single_bit_orig_name {div/val[15]}
set_db -quiet {inst:Exponent/div/val_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[15]/q} .original_name {div/val[15]/q}
set_db -quiet {inst:Exponent/div/val_reg[16]} .original_name {{div/val[16]}}
set_db -quiet {inst:Exponent/div/val_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[16]} .single_bit_orig_name {div/val[16]}
set_db -quiet {inst:Exponent/div/val_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[16]/q} .original_name {div/val[16]/q}
set_db -quiet {inst:Exponent/div/val_reg[17]} .original_name {{div/val[17]}}
set_db -quiet {inst:Exponent/div/val_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[17]} .single_bit_orig_name {div/val[17]}
set_db -quiet {inst:Exponent/div/val_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[17]/q} .original_name {div/val[17]/q}
set_db -quiet {inst:Exponent/div/val_reg[18]} .original_name {{div/val[18]}}
set_db -quiet {inst:Exponent/div/val_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[18]} .single_bit_orig_name {div/val[18]}
set_db -quiet {inst:Exponent/div/val_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[18]/q} .original_name {div/val[18]/q}
set_db -quiet {inst:Exponent/div/val_reg[19]} .original_name {{div/val[19]}}
set_db -quiet {inst:Exponent/div/val_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[19]} .single_bit_orig_name {div/val[19]}
set_db -quiet {inst:Exponent/div/val_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[19]/q} .original_name {div/val[19]/q}
set_db -quiet {inst:Exponent/div/val_reg[20]} .original_name {{div/val[20]}}
set_db -quiet {inst:Exponent/div/val_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[20]} .single_bit_orig_name {div/val[20]}
set_db -quiet {inst:Exponent/div/val_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[20]/q} .original_name {div/val[20]/q}
set_db -quiet {inst:Exponent/div/val_reg[21]} .original_name {{div/val[21]}}
set_db -quiet {inst:Exponent/div/val_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[21]} .single_bit_orig_name {div/val[21]}
set_db -quiet {inst:Exponent/div/val_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[21]/q} .original_name {div/val[21]/q}
set_db -quiet {inst:Exponent/div/val_reg[22]} .original_name {{div/val[22]}}
set_db -quiet {inst:Exponent/div/val_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[22]} .single_bit_orig_name {div/val[22]}
set_db -quiet {inst:Exponent/div/val_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[22]/q} .original_name {div/val[22]/q}
set_db -quiet {inst:Exponent/div/val_reg[23]} .original_name {{div/val[23]}}
set_db -quiet {inst:Exponent/div/val_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[23]} .single_bit_orig_name {div/val[23]}
set_db -quiet {inst:Exponent/div/val_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[23]/q} .original_name {div/val[23]/q}
set_db -quiet {inst:Exponent/div/val_reg[24]} .original_name {{div/val[24]}}
set_db -quiet {inst:Exponent/div/val_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[24]} .single_bit_orig_name {div/val[24]}
set_db -quiet {inst:Exponent/div/val_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[24]/q} .original_name {div/val[24]/q}
set_db -quiet {inst:Exponent/div/val_reg[25]} .original_name {{div/val[25]}}
set_db -quiet {inst:Exponent/div/val_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[25]} .single_bit_orig_name {div/val[25]}
set_db -quiet {inst:Exponent/div/val_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[25]/q} .original_name {div/val[25]/q}
set_db -quiet {inst:Exponent/div/val_reg[26]} .original_name {{div/val[26]}}
set_db -quiet {inst:Exponent/div/val_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[26]} .single_bit_orig_name {div/val[26]}
set_db -quiet {inst:Exponent/div/val_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[26]/q} .original_name {div/val[26]/q}
set_db -quiet {inst:Exponent/div/val_reg[27]} .original_name {{div/val[27]}}
set_db -quiet {inst:Exponent/div/val_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[27]} .single_bit_orig_name {div/val[27]}
set_db -quiet {inst:Exponent/div/val_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[27]/q} .original_name {div/val[27]/q}
set_db -quiet {inst:Exponent/div/val_reg[28]} .original_name {{div/val[28]}}
set_db -quiet {inst:Exponent/div/val_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[28]} .single_bit_orig_name {div/val[28]}
set_db -quiet {inst:Exponent/div/val_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[28]/q} .original_name {div/val[28]/q}
set_db -quiet {inst:Exponent/div/val_reg[29]} .original_name {{div/val[29]}}
set_db -quiet {inst:Exponent/div/val_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[29]} .single_bit_orig_name {div/val[29]}
set_db -quiet {inst:Exponent/div/val_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[29]/q} .original_name {div/val[29]/q}
set_db -quiet {inst:Exponent/div/val_reg[30]} .original_name {{div/val[30]}}
set_db -quiet {inst:Exponent/div/val_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[30]} .single_bit_orig_name {div/val[30]}
set_db -quiet {inst:Exponent/div/val_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[30]/q} .original_name {div/val[30]/q}
set_db -quiet {inst:Exponent/div/val_reg[31]} .original_name {{div/val[31]}}
set_db -quiet {inst:Exponent/div/val_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/val_reg[31]} .single_bit_orig_name {div/val[31]}
set_db -quiet {inst:Exponent/div/val_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/val_reg[31]/q} .original_name {div/val[31]/q}
set_db -quiet {inst:Exponent/div/rem_reg[0]} .original_name {{div/rem[0]}}
set_db -quiet {inst:Exponent/div/rem_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[0]} .single_bit_orig_name {div/rem[0]}
set_db -quiet {inst:Exponent/div/rem_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[0]/q} .original_name {div/rem[0]/q}
set_db -quiet {inst:Exponent/div/rem_reg[1]} .original_name {{div/rem[1]}}
set_db -quiet {inst:Exponent/div/rem_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[1]} .single_bit_orig_name {div/rem[1]}
set_db -quiet {inst:Exponent/div/rem_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[1]/q} .original_name {div/rem[1]/q}
set_db -quiet {inst:Exponent/div/rem_reg[2]} .original_name {{div/rem[2]}}
set_db -quiet {inst:Exponent/div/rem_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[2]} .single_bit_orig_name {div/rem[2]}
set_db -quiet {inst:Exponent/div/rem_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[2]/q} .original_name {div/rem[2]/q}
set_db -quiet {inst:Exponent/div/rem_reg[3]} .original_name {{div/rem[3]}}
set_db -quiet {inst:Exponent/div/rem_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[3]} .single_bit_orig_name {div/rem[3]}
set_db -quiet {inst:Exponent/div/rem_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[3]/q} .original_name {div/rem[3]/q}
set_db -quiet {inst:Exponent/div/rem_reg[4]} .original_name {{div/rem[4]}}
set_db -quiet {inst:Exponent/div/rem_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[4]} .single_bit_orig_name {div/rem[4]}
set_db -quiet {inst:Exponent/div/rem_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[4]/q} .original_name {div/rem[4]/q}
set_db -quiet {inst:Exponent/div/rem_reg[5]} .original_name {{div/rem[5]}}
set_db -quiet {inst:Exponent/div/rem_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[5]} .single_bit_orig_name {div/rem[5]}
set_db -quiet {inst:Exponent/div/rem_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[5]/q} .original_name {div/rem[5]/q}
set_db -quiet {inst:Exponent/div/rem_reg[6]} .original_name {{div/rem[6]}}
set_db -quiet {inst:Exponent/div/rem_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[6]} .single_bit_orig_name {div/rem[6]}
set_db -quiet {inst:Exponent/div/rem_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[6]/q} .original_name {div/rem[6]/q}
set_db -quiet {inst:Exponent/div/rem_reg[7]} .original_name {{div/rem[7]}}
set_db -quiet {inst:Exponent/div/rem_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[7]} .single_bit_orig_name {div/rem[7]}
set_db -quiet {inst:Exponent/div/rem_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[7]/q} .original_name {div/rem[7]/q}
set_db -quiet {inst:Exponent/div/rem_reg[8]} .original_name {{div/rem[8]}}
set_db -quiet {inst:Exponent/div/rem_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[8]} .single_bit_orig_name {div/rem[8]}
set_db -quiet {inst:Exponent/div/rem_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[8]/q} .original_name {div/rem[8]/q}
set_db -quiet {inst:Exponent/div/rem_reg[9]} .original_name {{div/rem[9]}}
set_db -quiet {inst:Exponent/div/rem_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[9]} .single_bit_orig_name {div/rem[9]}
set_db -quiet {inst:Exponent/div/rem_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[9]/q} .original_name {div/rem[9]/q}
set_db -quiet {inst:Exponent/div/rem_reg[10]} .original_name {{div/rem[10]}}
set_db -quiet {inst:Exponent/div/rem_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[10]} .single_bit_orig_name {div/rem[10]}
set_db -quiet {inst:Exponent/div/rem_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[10]/q} .original_name {div/rem[10]/q}
set_db -quiet {inst:Exponent/div/rem_reg[11]} .original_name {{div/rem[11]}}
set_db -quiet {inst:Exponent/div/rem_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[11]} .single_bit_orig_name {div/rem[11]}
set_db -quiet {inst:Exponent/div/rem_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[11]/q} .original_name {div/rem[11]/q}
set_db -quiet {inst:Exponent/div/rem_reg[12]} .original_name {{div/rem[12]}}
set_db -quiet {inst:Exponent/div/rem_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[12]} .single_bit_orig_name {div/rem[12]}
set_db -quiet {inst:Exponent/div/rem_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[12]/q} .original_name {div/rem[12]/q}
set_db -quiet {inst:Exponent/div/rem_reg[13]} .original_name {{div/rem[13]}}
set_db -quiet {inst:Exponent/div/rem_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[13]} .single_bit_orig_name {div/rem[13]}
set_db -quiet {inst:Exponent/div/rem_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[13]/q} .original_name {div/rem[13]/q}
set_db -quiet {inst:Exponent/div/rem_reg[14]} .original_name {{div/rem[14]}}
set_db -quiet {inst:Exponent/div/rem_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[14]} .single_bit_orig_name {div/rem[14]}
set_db -quiet {inst:Exponent/div/rem_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[14]/q} .original_name {div/rem[14]/q}
set_db -quiet {inst:Exponent/div/rem_reg[15]} .original_name {{div/rem[15]}}
set_db -quiet {inst:Exponent/div/rem_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[15]} .single_bit_orig_name {div/rem[15]}
set_db -quiet {inst:Exponent/div/rem_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[15]/q} .original_name {div/rem[15]/q}
set_db -quiet {inst:Exponent/div/rem_reg[16]} .original_name {{div/rem[16]}}
set_db -quiet {inst:Exponent/div/rem_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[16]} .single_bit_orig_name {div/rem[16]}
set_db -quiet {inst:Exponent/div/rem_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[16]/q} .original_name {div/rem[16]/q}
set_db -quiet {inst:Exponent/div/rem_reg[17]} .original_name {{div/rem[17]}}
set_db -quiet {inst:Exponent/div/rem_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[17]} .single_bit_orig_name {div/rem[17]}
set_db -quiet {inst:Exponent/div/rem_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[17]/q} .original_name {div/rem[17]/q}
set_db -quiet {inst:Exponent/div/rem_reg[18]} .original_name {{div/rem[18]}}
set_db -quiet {inst:Exponent/div/rem_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[18]} .single_bit_orig_name {div/rem[18]}
set_db -quiet {inst:Exponent/div/rem_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[18]/q} .original_name {div/rem[18]/q}
set_db -quiet {inst:Exponent/div/rem_reg[19]} .original_name {{div/rem[19]}}
set_db -quiet {inst:Exponent/div/rem_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[19]} .single_bit_orig_name {div/rem[19]}
set_db -quiet {inst:Exponent/div/rem_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[19]/q} .original_name {div/rem[19]/q}
set_db -quiet {inst:Exponent/div/rem_reg[20]} .original_name {{div/rem[20]}}
set_db -quiet {inst:Exponent/div/rem_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[20]} .single_bit_orig_name {div/rem[20]}
set_db -quiet {inst:Exponent/div/rem_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[20]/q} .original_name {div/rem[20]/q}
set_db -quiet {inst:Exponent/div/rem_reg[21]} .original_name {{div/rem[21]}}
set_db -quiet {inst:Exponent/div/rem_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[21]} .single_bit_orig_name {div/rem[21]}
set_db -quiet {inst:Exponent/div/rem_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[21]/q} .original_name {div/rem[21]/q}
set_db -quiet {inst:Exponent/div/rem_reg[22]} .original_name {{div/rem[22]}}
set_db -quiet {inst:Exponent/div/rem_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[22]} .single_bit_orig_name {div/rem[22]}
set_db -quiet {inst:Exponent/div/rem_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[22]/q} .original_name {div/rem[22]/q}
set_db -quiet {inst:Exponent/div/rem_reg[23]} .original_name {{div/rem[23]}}
set_db -quiet {inst:Exponent/div/rem_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[23]} .single_bit_orig_name {div/rem[23]}
set_db -quiet {inst:Exponent/div/rem_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[23]/q} .original_name {div/rem[23]/q}
set_db -quiet {inst:Exponent/div/rem_reg[24]} .original_name {{div/rem[24]}}
set_db -quiet {inst:Exponent/div/rem_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[24]} .single_bit_orig_name {div/rem[24]}
set_db -quiet {inst:Exponent/div/rem_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[24]/q} .original_name {div/rem[24]/q}
set_db -quiet {inst:Exponent/div/rem_reg[25]} .original_name {{div/rem[25]}}
set_db -quiet {inst:Exponent/div/rem_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[25]} .single_bit_orig_name {div/rem[25]}
set_db -quiet {inst:Exponent/div/rem_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[25]/q} .original_name {div/rem[25]/q}
set_db -quiet {inst:Exponent/div/rem_reg[26]} .original_name {{div/rem[26]}}
set_db -quiet {inst:Exponent/div/rem_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[26]} .single_bit_orig_name {div/rem[26]}
set_db -quiet {inst:Exponent/div/rem_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[26]/q} .original_name {div/rem[26]/q}
set_db -quiet {inst:Exponent/div/rem_reg[27]} .original_name {{div/rem[27]}}
set_db -quiet {inst:Exponent/div/rem_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[27]} .single_bit_orig_name {div/rem[27]}
set_db -quiet {inst:Exponent/div/rem_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[27]/q} .original_name {div/rem[27]/q}
set_db -quiet {inst:Exponent/div/rem_reg[28]} .original_name {{div/rem[28]}}
set_db -quiet {inst:Exponent/div/rem_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[28]} .single_bit_orig_name {div/rem[28]}
set_db -quiet {inst:Exponent/div/rem_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[28]/q} .original_name {div/rem[28]/q}
set_db -quiet {inst:Exponent/div/rem_reg[29]} .original_name {{div/rem[29]}}
set_db -quiet {inst:Exponent/div/rem_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[29]} .single_bit_orig_name {div/rem[29]}
set_db -quiet {inst:Exponent/div/rem_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[29]/q} .original_name {div/rem[29]/q}
set_db -quiet {inst:Exponent/div/rem_reg[30]} .original_name {{div/rem[30]}}
set_db -quiet {inst:Exponent/div/rem_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[30]} .single_bit_orig_name {div/rem[30]}
set_db -quiet {inst:Exponent/div/rem_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[30]/q} .original_name {div/rem[30]/q}
set_db -quiet {inst:Exponent/div/rem_reg[31]} .original_name {{div/rem[31]}}
set_db -quiet {inst:Exponent/div/rem_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/rem_reg[31]} .single_bit_orig_name {div/rem[31]}
set_db -quiet {inst:Exponent/div/rem_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/rem_reg[31]/q} .original_name {div/rem[31]/q}
set_db -quiet {inst:Exponent/div/b1_reg[0]} .original_name {{div/b1[0]}}
set_db -quiet {inst:Exponent/div/b1_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[0]} .single_bit_orig_name {div/b1[0]}
set_db -quiet {inst:Exponent/div/b1_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[0]/q} .original_name {div/b1[0]/q}
set_db -quiet {inst:Exponent/div/b1_reg[1]} .original_name {{div/b1[1]}}
set_db -quiet {inst:Exponent/div/b1_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[1]} .single_bit_orig_name {div/b1[1]}
set_db -quiet {inst:Exponent/div/b1_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[1]/q} .original_name {div/b1[1]/q}
set_db -quiet {inst:Exponent/div/b1_reg[2]} .original_name {{div/b1[2]}}
set_db -quiet {inst:Exponent/div/b1_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[2]} .single_bit_orig_name {div/b1[2]}
set_db -quiet {inst:Exponent/div/b1_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[2]/q} .original_name {div/b1[2]/q}
set_db -quiet {inst:Exponent/div/b1_reg[3]} .original_name {{div/b1[3]}}
set_db -quiet {inst:Exponent/div/b1_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[3]} .single_bit_orig_name {div/b1[3]}
set_db -quiet {inst:Exponent/div/b1_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[3]/q} .original_name {div/b1[3]/q}
set_db -quiet {inst:Exponent/div/b1_reg[4]} .original_name {{div/b1[4]}}
set_db -quiet {inst:Exponent/div/b1_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[4]} .single_bit_orig_name {div/b1[4]}
set_db -quiet {inst:Exponent/div/b1_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[4]/q} .original_name {div/b1[4]/q}
set_db -quiet {inst:Exponent/div/b1_reg[5]} .original_name {{div/b1[5]}}
set_db -quiet {inst:Exponent/div/b1_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[5]} .single_bit_orig_name {div/b1[5]}
set_db -quiet {inst:Exponent/div/b1_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[5]/q} .original_name {div/b1[5]/q}
set_db -quiet {inst:Exponent/div/b1_reg[6]} .original_name {{div/b1[6]}}
set_db -quiet {inst:Exponent/div/b1_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[6]} .single_bit_orig_name {div/b1[6]}
set_db -quiet {inst:Exponent/div/b1_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[6]/q} .original_name {div/b1[6]/q}
set_db -quiet {inst:Exponent/div/b1_reg[7]} .original_name {{div/b1[7]}}
set_db -quiet {inst:Exponent/div/b1_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[7]} .single_bit_orig_name {div/b1[7]}
set_db -quiet {inst:Exponent/div/b1_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[7]/q} .original_name {div/b1[7]/q}
set_db -quiet {inst:Exponent/div/b1_reg[8]} .original_name {{div/b1[8]}}
set_db -quiet {inst:Exponent/div/b1_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[8]} .single_bit_orig_name {div/b1[8]}
set_db -quiet {inst:Exponent/div/b1_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[8]/q} .original_name {div/b1[8]/q}
set_db -quiet {inst:Exponent/div/b1_reg[9]} .original_name {{div/b1[9]}}
set_db -quiet {inst:Exponent/div/b1_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[9]} .single_bit_orig_name {div/b1[9]}
set_db -quiet {inst:Exponent/div/b1_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[9]/q} .original_name {div/b1[9]/q}
set_db -quiet {inst:Exponent/div/b1_reg[10]} .original_name {{div/b1[10]}}
set_db -quiet {inst:Exponent/div/b1_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[10]} .single_bit_orig_name {div/b1[10]}
set_db -quiet {inst:Exponent/div/b1_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[10]/q} .original_name {div/b1[10]/q}
set_db -quiet {inst:Exponent/div/b1_reg[11]} .original_name {{div/b1[11]}}
set_db -quiet {inst:Exponent/div/b1_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[11]} .single_bit_orig_name {div/b1[11]}
set_db -quiet {inst:Exponent/div/b1_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[11]/q} .original_name {div/b1[11]/q}
set_db -quiet {inst:Exponent/div/b1_reg[12]} .original_name {{div/b1[12]}}
set_db -quiet {inst:Exponent/div/b1_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[12]} .single_bit_orig_name {div/b1[12]}
set_db -quiet {inst:Exponent/div/b1_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[12]/q} .original_name {div/b1[12]/q}
set_db -quiet {inst:Exponent/div/b1_reg[13]} .original_name {{div/b1[13]}}
set_db -quiet {inst:Exponent/div/b1_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[13]} .single_bit_orig_name {div/b1[13]}
set_db -quiet {inst:Exponent/div/b1_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[13]/q} .original_name {div/b1[13]/q}
set_db -quiet {inst:Exponent/div/b1_reg[14]} .original_name {{div/b1[14]}}
set_db -quiet {inst:Exponent/div/b1_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[14]} .single_bit_orig_name {div/b1[14]}
set_db -quiet {inst:Exponent/div/b1_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[14]/q} .original_name {div/b1[14]/q}
set_db -quiet {inst:Exponent/div/b1_reg[15]} .original_name {{div/b1[15]}}
set_db -quiet {inst:Exponent/div/b1_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[15]} .single_bit_orig_name {div/b1[15]}
set_db -quiet {inst:Exponent/div/b1_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[15]/q} .original_name {div/b1[15]/q}
set_db -quiet {inst:Exponent/div/b1_reg[16]} .original_name {{div/b1[16]}}
set_db -quiet {inst:Exponent/div/b1_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[16]} .single_bit_orig_name {div/b1[16]}
set_db -quiet {inst:Exponent/div/b1_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[16]/q} .original_name {div/b1[16]/q}
set_db -quiet {inst:Exponent/div/b1_reg[17]} .original_name {{div/b1[17]}}
set_db -quiet {inst:Exponent/div/b1_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[17]} .single_bit_orig_name {div/b1[17]}
set_db -quiet {inst:Exponent/div/b1_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[17]/q} .original_name {div/b1[17]/q}
set_db -quiet {inst:Exponent/div/b1_reg[18]} .original_name {{div/b1[18]}}
set_db -quiet {inst:Exponent/div/b1_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[18]} .single_bit_orig_name {div/b1[18]}
set_db -quiet {inst:Exponent/div/b1_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[18]/q} .original_name {div/b1[18]/q}
set_db -quiet {inst:Exponent/div/b1_reg[19]} .original_name {{div/b1[19]}}
set_db -quiet {inst:Exponent/div/b1_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[19]} .single_bit_orig_name {div/b1[19]}
set_db -quiet {inst:Exponent/div/b1_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[19]/q} .original_name {div/b1[19]/q}
set_db -quiet {inst:Exponent/div/b1_reg[20]} .original_name {{div/b1[20]}}
set_db -quiet {inst:Exponent/div/b1_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[20]} .single_bit_orig_name {div/b1[20]}
set_db -quiet {inst:Exponent/div/b1_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[20]/q} .original_name {div/b1[20]/q}
set_db -quiet {inst:Exponent/div/b1_reg[21]} .original_name {{div/b1[21]}}
set_db -quiet {inst:Exponent/div/b1_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[21]} .single_bit_orig_name {div/b1[21]}
set_db -quiet {inst:Exponent/div/b1_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[21]/q} .original_name {div/b1[21]/q}
set_db -quiet {inst:Exponent/div/b1_reg[22]} .original_name {{div/b1[22]}}
set_db -quiet {inst:Exponent/div/b1_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[22]} .single_bit_orig_name {div/b1[22]}
set_db -quiet {inst:Exponent/div/b1_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[22]/q} .original_name {div/b1[22]/q}
set_db -quiet {inst:Exponent/div/b1_reg[23]} .original_name {{div/b1[23]}}
set_db -quiet {inst:Exponent/div/b1_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[23]} .single_bit_orig_name {div/b1[23]}
set_db -quiet {inst:Exponent/div/b1_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[23]/q} .original_name {div/b1[23]/q}
set_db -quiet {inst:Exponent/div/b1_reg[24]} .original_name {{div/b1[24]}}
set_db -quiet {inst:Exponent/div/b1_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[24]} .single_bit_orig_name {div/b1[24]}
set_db -quiet {inst:Exponent/div/b1_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[24]/q} .original_name {div/b1[24]/q}
set_db -quiet {inst:Exponent/div/b1_reg[25]} .original_name {{div/b1[25]}}
set_db -quiet {inst:Exponent/div/b1_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[25]} .single_bit_orig_name {div/b1[25]}
set_db -quiet {inst:Exponent/div/b1_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[25]/q} .original_name {div/b1[25]/q}
set_db -quiet {inst:Exponent/div/b1_reg[26]} .original_name {{div/b1[26]}}
set_db -quiet {inst:Exponent/div/b1_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[26]} .single_bit_orig_name {div/b1[26]}
set_db -quiet {inst:Exponent/div/b1_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[26]/q} .original_name {div/b1[26]/q}
set_db -quiet {inst:Exponent/div/b1_reg[27]} .original_name {{div/b1[27]}}
set_db -quiet {inst:Exponent/div/b1_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[27]} .single_bit_orig_name {div/b1[27]}
set_db -quiet {inst:Exponent/div/b1_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[27]/q} .original_name {div/b1[27]/q}
set_db -quiet {inst:Exponent/div/b1_reg[28]} .original_name {{div/b1[28]}}
set_db -quiet {inst:Exponent/div/b1_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[28]} .single_bit_orig_name {div/b1[28]}
set_db -quiet {inst:Exponent/div/b1_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[28]/q} .original_name {div/b1[28]/q}
set_db -quiet {inst:Exponent/div/b1_reg[29]} .original_name {{div/b1[29]}}
set_db -quiet {inst:Exponent/div/b1_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[29]} .single_bit_orig_name {div/b1[29]}
set_db -quiet {inst:Exponent/div/b1_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[29]/q} .original_name {div/b1[29]/q}
set_db -quiet {inst:Exponent/div/b1_reg[30]} .original_name {{div/b1[30]}}
set_db -quiet {inst:Exponent/div/b1_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[30]} .single_bit_orig_name {div/b1[30]}
set_db -quiet {inst:Exponent/div/b1_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[30]/q} .original_name {div/b1[30]/q}
set_db -quiet {inst:Exponent/div/b1_reg[31]} .original_name {{div/b1[31]}}
set_db -quiet {inst:Exponent/div/b1_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/b1_reg[31]} .single_bit_orig_name {div/b1[31]}
set_db -quiet {inst:Exponent/div/b1_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/b1_reg[31]/q} .original_name {div/b1[31]/q}
set_db -quiet {inst:Exponent/div/quo_reg[0]} .original_name {{div/quo[0]}}
set_db -quiet {inst:Exponent/div/quo_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[0]} .single_bit_orig_name {div/quo[0]}
set_db -quiet {inst:Exponent/div/quo_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[0]/q} .original_name {div/quo[0]/q}
set_db -quiet {inst:Exponent/div/quo_reg[1]} .original_name {{div/quo[1]}}
set_db -quiet {inst:Exponent/div/quo_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[1]} .single_bit_orig_name {div/quo[1]}
set_db -quiet {inst:Exponent/div/quo_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[1]/q} .original_name {div/quo[1]/q}
set_db -quiet {inst:Exponent/div/quo_reg[2]} .original_name {{div/quo[2]}}
set_db -quiet {inst:Exponent/div/quo_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[2]} .single_bit_orig_name {div/quo[2]}
set_db -quiet {inst:Exponent/div/quo_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[2]/q} .original_name {div/quo[2]/q}
set_db -quiet {inst:Exponent/div/quo_reg[3]} .original_name {{div/quo[3]}}
set_db -quiet {inst:Exponent/div/quo_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[3]} .single_bit_orig_name {div/quo[3]}
set_db -quiet {inst:Exponent/div/quo_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[3]/q} .original_name {div/quo[3]/q}
set_db -quiet {inst:Exponent/div/quo_reg[4]} .original_name {{div/quo[4]}}
set_db -quiet {inst:Exponent/div/quo_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[4]} .single_bit_orig_name {div/quo[4]}
set_db -quiet {inst:Exponent/div/quo_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[4]/q} .original_name {div/quo[4]/q}
set_db -quiet {inst:Exponent/div/quo_reg[5]} .original_name {{div/quo[5]}}
set_db -quiet {inst:Exponent/div/quo_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[5]} .single_bit_orig_name {div/quo[5]}
set_db -quiet {inst:Exponent/div/quo_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[5]/q} .original_name {div/quo[5]/q}
set_db -quiet {inst:Exponent/div/quo_reg[6]} .original_name {{div/quo[6]}}
set_db -quiet {inst:Exponent/div/quo_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[6]} .single_bit_orig_name {div/quo[6]}
set_db -quiet {inst:Exponent/div/quo_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[6]/q} .original_name {div/quo[6]/q}
set_db -quiet {inst:Exponent/div/quo_reg[7]} .original_name {{div/quo[7]}}
set_db -quiet {inst:Exponent/div/quo_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[7]} .single_bit_orig_name {div/quo[7]}
set_db -quiet {inst:Exponent/div/quo_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[7]/q} .original_name {div/quo[7]/q}
set_db -quiet {inst:Exponent/div/quo_reg[8]} .original_name {{div/quo[8]}}
set_db -quiet {inst:Exponent/div/quo_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[8]} .single_bit_orig_name {div/quo[8]}
set_db -quiet {inst:Exponent/div/quo_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[8]/q} .original_name {div/quo[8]/q}
set_db -quiet {inst:Exponent/div/quo_reg[9]} .original_name {{div/quo[9]}}
set_db -quiet {inst:Exponent/div/quo_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[9]} .single_bit_orig_name {div/quo[9]}
set_db -quiet {inst:Exponent/div/quo_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[9]/q} .original_name {div/quo[9]/q}
set_db -quiet {inst:Exponent/div/quo_reg[10]} .original_name {{div/quo[10]}}
set_db -quiet {inst:Exponent/div/quo_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[10]} .single_bit_orig_name {div/quo[10]}
set_db -quiet {inst:Exponent/div/quo_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[10]/q} .original_name {div/quo[10]/q}
set_db -quiet {inst:Exponent/div/quo_reg[11]} .original_name {{div/quo[11]}}
set_db -quiet {inst:Exponent/div/quo_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[11]} .single_bit_orig_name {div/quo[11]}
set_db -quiet {inst:Exponent/div/quo_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[11]/q} .original_name {div/quo[11]/q}
set_db -quiet {inst:Exponent/div/quo_reg[12]} .original_name {{div/quo[12]}}
set_db -quiet {inst:Exponent/div/quo_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[12]} .single_bit_orig_name {div/quo[12]}
set_db -quiet {inst:Exponent/div/quo_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[12]/q} .original_name {div/quo[12]/q}
set_db -quiet {inst:Exponent/div/quo_reg[13]} .original_name {{div/quo[13]}}
set_db -quiet {inst:Exponent/div/quo_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[13]} .single_bit_orig_name {div/quo[13]}
set_db -quiet {inst:Exponent/div/quo_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[13]/q} .original_name {div/quo[13]/q}
set_db -quiet {inst:Exponent/div/quo_reg[14]} .original_name {{div/quo[14]}}
set_db -quiet {inst:Exponent/div/quo_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[14]} .single_bit_orig_name {div/quo[14]}
set_db -quiet {inst:Exponent/div/quo_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[14]/q} .original_name {div/quo[14]/q}
set_db -quiet {inst:Exponent/div/quo_reg[15]} .original_name {{div/quo[15]}}
set_db -quiet {inst:Exponent/div/quo_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[15]} .single_bit_orig_name {div/quo[15]}
set_db -quiet {inst:Exponent/div/quo_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[15]/q} .original_name {div/quo[15]/q}
set_db -quiet {inst:Exponent/div/quo_reg[16]} .original_name {{div/quo[16]}}
set_db -quiet {inst:Exponent/div/quo_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[16]} .single_bit_orig_name {div/quo[16]}
set_db -quiet {inst:Exponent/div/quo_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[16]/q} .original_name {div/quo[16]/q}
set_db -quiet {inst:Exponent/div/quo_reg[17]} .original_name {{div/quo[17]}}
set_db -quiet {inst:Exponent/div/quo_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[17]} .single_bit_orig_name {div/quo[17]}
set_db -quiet {inst:Exponent/div/quo_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[17]/q} .original_name {div/quo[17]/q}
set_db -quiet {inst:Exponent/div/quo_reg[18]} .original_name {{div/quo[18]}}
set_db -quiet {inst:Exponent/div/quo_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[18]} .single_bit_orig_name {div/quo[18]}
set_db -quiet {inst:Exponent/div/quo_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[18]/q} .original_name {div/quo[18]/q}
set_db -quiet {inst:Exponent/div/quo_reg[19]} .original_name {{div/quo[19]}}
set_db -quiet {inst:Exponent/div/quo_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[19]} .single_bit_orig_name {div/quo[19]}
set_db -quiet {inst:Exponent/div/quo_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[19]/q} .original_name {div/quo[19]/q}
set_db -quiet {inst:Exponent/div/quo_reg[20]} .original_name {{div/quo[20]}}
set_db -quiet {inst:Exponent/div/quo_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[20]} .single_bit_orig_name {div/quo[20]}
set_db -quiet {inst:Exponent/div/quo_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[20]/q} .original_name {div/quo[20]/q}
set_db -quiet {inst:Exponent/div/quo_reg[21]} .original_name {{div/quo[21]}}
set_db -quiet {inst:Exponent/div/quo_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[21]} .single_bit_orig_name {div/quo[21]}
set_db -quiet {inst:Exponent/div/quo_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[21]/q} .original_name {div/quo[21]/q}
set_db -quiet {inst:Exponent/div/quo_reg[22]} .original_name {{div/quo[22]}}
set_db -quiet {inst:Exponent/div/quo_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[22]} .single_bit_orig_name {div/quo[22]}
set_db -quiet {inst:Exponent/div/quo_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[22]/q} .original_name {div/quo[22]/q}
set_db -quiet {inst:Exponent/div/quo_reg[23]} .original_name {{div/quo[23]}}
set_db -quiet {inst:Exponent/div/quo_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[23]} .single_bit_orig_name {div/quo[23]}
set_db -quiet {inst:Exponent/div/quo_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[23]/q} .original_name {div/quo[23]/q}
set_db -quiet {inst:Exponent/div/quo_reg[24]} .original_name {{div/quo[24]}}
set_db -quiet {inst:Exponent/div/quo_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[24]} .single_bit_orig_name {div/quo[24]}
set_db -quiet {inst:Exponent/div/quo_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[24]/q} .original_name {div/quo[24]/q}
set_db -quiet {inst:Exponent/div/quo_reg[25]} .original_name {{div/quo[25]}}
set_db -quiet {inst:Exponent/div/quo_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[25]} .single_bit_orig_name {div/quo[25]}
set_db -quiet {inst:Exponent/div/quo_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[25]/q} .original_name {div/quo[25]/q}
set_db -quiet {inst:Exponent/div/quo_reg[26]} .original_name {{div/quo[26]}}
set_db -quiet {inst:Exponent/div/quo_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[26]} .single_bit_orig_name {div/quo[26]}
set_db -quiet {inst:Exponent/div/quo_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[26]/q} .original_name {div/quo[26]/q}
set_db -quiet {inst:Exponent/div/quo_reg[27]} .original_name {{div/quo[27]}}
set_db -quiet {inst:Exponent/div/quo_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[27]} .single_bit_orig_name {div/quo[27]}
set_db -quiet {inst:Exponent/div/quo_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[27]/q} .original_name {div/quo[27]/q}
set_db -quiet {inst:Exponent/div/quo_reg[28]} .original_name {{div/quo[28]}}
set_db -quiet {inst:Exponent/div/quo_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[28]} .single_bit_orig_name {div/quo[28]}
set_db -quiet {inst:Exponent/div/quo_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[28]/q} .original_name {div/quo[28]/q}
set_db -quiet {inst:Exponent/div/quo_reg[29]} .original_name {{div/quo[29]}}
set_db -quiet {inst:Exponent/div/quo_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[29]} .single_bit_orig_name {div/quo[29]}
set_db -quiet {inst:Exponent/div/quo_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[29]/q} .original_name {div/quo[29]/q}
set_db -quiet {inst:Exponent/div/quo_reg[30]} .original_name {{div/quo[30]}}
set_db -quiet {inst:Exponent/div/quo_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[30]} .single_bit_orig_name {div/quo[30]}
set_db -quiet {inst:Exponent/div/quo_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[30]/q} .original_name {div/quo[30]/q}
set_db -quiet {inst:Exponent/div/quo_reg[31]} .original_name {{div/quo[31]}}
set_db -quiet {inst:Exponent/div/quo_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/quo_reg[31]} .single_bit_orig_name {div/quo[31]}
set_db -quiet {inst:Exponent/div/quo_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/quo_reg[31]/q} .original_name {div/quo[31]/q}
set_db -quiet {inst:Exponent/div/acc_reg[0]} .original_name {{div/acc[0]}}
set_db -quiet {inst:Exponent/div/acc_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[0]} .single_bit_orig_name {div/acc[0]}
set_db -quiet {inst:Exponent/div/acc_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[0]/q} .original_name {div/acc[0]/q}
set_db -quiet {inst:Exponent/div/acc_reg[1]} .original_name {{div/acc[1]}}
set_db -quiet {inst:Exponent/div/acc_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[1]} .single_bit_orig_name {div/acc[1]}
set_db -quiet {inst:Exponent/div/acc_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[1]/q} .original_name {div/acc[1]/q}
set_db -quiet {inst:Exponent/div/acc_reg[2]} .original_name {{div/acc[2]}}
set_db -quiet {inst:Exponent/div/acc_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[2]} .single_bit_orig_name {div/acc[2]}
set_db -quiet {inst:Exponent/div/acc_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[2]/q} .original_name {div/acc[2]/q}
set_db -quiet {inst:Exponent/div/acc_reg[3]} .original_name {{div/acc[3]}}
set_db -quiet {inst:Exponent/div/acc_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[3]} .single_bit_orig_name {div/acc[3]}
set_db -quiet {inst:Exponent/div/acc_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[3]/q} .original_name {div/acc[3]/q}
set_db -quiet {inst:Exponent/div/acc_reg[4]} .original_name {{div/acc[4]}}
set_db -quiet {inst:Exponent/div/acc_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[4]} .single_bit_orig_name {div/acc[4]}
set_db -quiet {inst:Exponent/div/acc_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[4]/q} .original_name {div/acc[4]/q}
set_db -quiet {inst:Exponent/div/acc_reg[5]} .original_name {{div/acc[5]}}
set_db -quiet {inst:Exponent/div/acc_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[5]} .single_bit_orig_name {div/acc[5]}
set_db -quiet {inst:Exponent/div/acc_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[5]/q} .original_name {div/acc[5]/q}
set_db -quiet {inst:Exponent/div/acc_reg[6]} .original_name {{div/acc[6]}}
set_db -quiet {inst:Exponent/div/acc_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[6]} .single_bit_orig_name {div/acc[6]}
set_db -quiet {inst:Exponent/div/acc_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[6]/q} .original_name {div/acc[6]/q}
set_db -quiet {inst:Exponent/div/acc_reg[7]} .original_name {{div/acc[7]}}
set_db -quiet {inst:Exponent/div/acc_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[7]} .single_bit_orig_name {div/acc[7]}
set_db -quiet {inst:Exponent/div/acc_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[7]/q} .original_name {div/acc[7]/q}
set_db -quiet {inst:Exponent/div/acc_reg[8]} .original_name {{div/acc[8]}}
set_db -quiet {inst:Exponent/div/acc_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[8]} .single_bit_orig_name {div/acc[8]}
set_db -quiet {inst:Exponent/div/acc_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[8]/q} .original_name {div/acc[8]/q}
set_db -quiet {inst:Exponent/div/acc_reg[9]} .original_name {{div/acc[9]}}
set_db -quiet {inst:Exponent/div/acc_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[9]} .single_bit_orig_name {div/acc[9]}
set_db -quiet {inst:Exponent/div/acc_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[9]/q} .original_name {div/acc[9]/q}
set_db -quiet {inst:Exponent/div/acc_reg[10]} .original_name {{div/acc[10]}}
set_db -quiet {inst:Exponent/div/acc_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[10]} .single_bit_orig_name {div/acc[10]}
set_db -quiet {inst:Exponent/div/acc_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[10]/q} .original_name {div/acc[10]/q}
set_db -quiet {inst:Exponent/div/acc_reg[11]} .original_name {{div/acc[11]}}
set_db -quiet {inst:Exponent/div/acc_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[11]} .single_bit_orig_name {div/acc[11]}
set_db -quiet {inst:Exponent/div/acc_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[11]/q} .original_name {div/acc[11]/q}
set_db -quiet {inst:Exponent/div/acc_reg[12]} .original_name {{div/acc[12]}}
set_db -quiet {inst:Exponent/div/acc_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[12]} .single_bit_orig_name {div/acc[12]}
set_db -quiet {inst:Exponent/div/acc_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[12]/q} .original_name {div/acc[12]/q}
set_db -quiet {inst:Exponent/div/acc_reg[13]} .original_name {{div/acc[13]}}
set_db -quiet {inst:Exponent/div/acc_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[13]} .single_bit_orig_name {div/acc[13]}
set_db -quiet {inst:Exponent/div/acc_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[13]/q} .original_name {div/acc[13]/q}
set_db -quiet {inst:Exponent/div/acc_reg[14]} .original_name {{div/acc[14]}}
set_db -quiet {inst:Exponent/div/acc_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[14]} .single_bit_orig_name {div/acc[14]}
set_db -quiet {inst:Exponent/div/acc_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[14]/q} .original_name {div/acc[14]/q}
set_db -quiet {inst:Exponent/div/acc_reg[15]} .original_name {{div/acc[15]}}
set_db -quiet {inst:Exponent/div/acc_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[15]} .single_bit_orig_name {div/acc[15]}
set_db -quiet {inst:Exponent/div/acc_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[15]/q} .original_name {div/acc[15]/q}
set_db -quiet {inst:Exponent/div/acc_reg[16]} .original_name {{div/acc[16]}}
set_db -quiet {inst:Exponent/div/acc_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[16]} .single_bit_orig_name {div/acc[16]}
set_db -quiet {inst:Exponent/div/acc_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[16]/q} .original_name {div/acc[16]/q}
set_db -quiet {inst:Exponent/div/acc_reg[17]} .original_name {{div/acc[17]}}
set_db -quiet {inst:Exponent/div/acc_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[17]} .single_bit_orig_name {div/acc[17]}
set_db -quiet {inst:Exponent/div/acc_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[17]/q} .original_name {div/acc[17]/q}
set_db -quiet {inst:Exponent/div/acc_reg[18]} .original_name {{div/acc[18]}}
set_db -quiet {inst:Exponent/div/acc_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[18]} .single_bit_orig_name {div/acc[18]}
set_db -quiet {inst:Exponent/div/acc_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[18]/q} .original_name {div/acc[18]/q}
set_db -quiet {inst:Exponent/div/acc_reg[19]} .original_name {{div/acc[19]}}
set_db -quiet {inst:Exponent/div/acc_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[19]} .single_bit_orig_name {div/acc[19]}
set_db -quiet {inst:Exponent/div/acc_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[19]/q} .original_name {div/acc[19]/q}
set_db -quiet {inst:Exponent/div/acc_reg[20]} .original_name {{div/acc[20]}}
set_db -quiet {inst:Exponent/div/acc_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[20]} .single_bit_orig_name {div/acc[20]}
set_db -quiet {inst:Exponent/div/acc_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[20]/q} .original_name {div/acc[20]/q}
set_db -quiet {inst:Exponent/div/acc_reg[21]} .original_name {{div/acc[21]}}
set_db -quiet {inst:Exponent/div/acc_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[21]} .single_bit_orig_name {div/acc[21]}
set_db -quiet {inst:Exponent/div/acc_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[21]/q} .original_name {div/acc[21]/q}
set_db -quiet {inst:Exponent/div/acc_reg[22]} .original_name {{div/acc[22]}}
set_db -quiet {inst:Exponent/div/acc_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[22]} .single_bit_orig_name {div/acc[22]}
set_db -quiet {inst:Exponent/div/acc_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[22]/q} .original_name {div/acc[22]/q}
set_db -quiet {inst:Exponent/div/acc_reg[23]} .original_name {{div/acc[23]}}
set_db -quiet {inst:Exponent/div/acc_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[23]} .single_bit_orig_name {div/acc[23]}
set_db -quiet {inst:Exponent/div/acc_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[23]/q} .original_name {div/acc[23]/q}
set_db -quiet {inst:Exponent/div/acc_reg[24]} .original_name {{div/acc[24]}}
set_db -quiet {inst:Exponent/div/acc_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[24]} .single_bit_orig_name {div/acc[24]}
set_db -quiet {inst:Exponent/div/acc_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[24]/q} .original_name {div/acc[24]/q}
set_db -quiet {inst:Exponent/div/acc_reg[25]} .original_name {{div/acc[25]}}
set_db -quiet {inst:Exponent/div/acc_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[25]} .single_bit_orig_name {div/acc[25]}
set_db -quiet {inst:Exponent/div/acc_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[25]/q} .original_name {div/acc[25]/q}
set_db -quiet {inst:Exponent/div/acc_reg[26]} .original_name {{div/acc[26]}}
set_db -quiet {inst:Exponent/div/acc_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[26]} .single_bit_orig_name {div/acc[26]}
set_db -quiet {inst:Exponent/div/acc_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[26]/q} .original_name {div/acc[26]/q}
set_db -quiet {inst:Exponent/div/acc_reg[27]} .original_name {{div/acc[27]}}
set_db -quiet {inst:Exponent/div/acc_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[27]} .single_bit_orig_name {div/acc[27]}
set_db -quiet {inst:Exponent/div/acc_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[27]/q} .original_name {div/acc[27]/q}
set_db -quiet {inst:Exponent/div/acc_reg[28]} .original_name {{div/acc[28]}}
set_db -quiet {inst:Exponent/div/acc_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[28]} .single_bit_orig_name {div/acc[28]}
set_db -quiet {inst:Exponent/div/acc_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[28]/q} .original_name {div/acc[28]/q}
set_db -quiet {inst:Exponent/div/acc_reg[29]} .original_name {{div/acc[29]}}
set_db -quiet {inst:Exponent/div/acc_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[29]} .single_bit_orig_name {div/acc[29]}
set_db -quiet {inst:Exponent/div/acc_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[29]/q} .original_name {div/acc[29]/q}
set_db -quiet {inst:Exponent/div/acc_reg[30]} .original_name {{div/acc[30]}}
set_db -quiet {inst:Exponent/div/acc_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[30]} .single_bit_orig_name {div/acc[30]}
set_db -quiet {inst:Exponent/div/acc_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[30]/q} .original_name {div/acc[30]/q}
set_db -quiet {inst:Exponent/div/acc_reg[31]} .original_name {{div/acc[31]}}
set_db -quiet {inst:Exponent/div/acc_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[31]} .single_bit_orig_name {div/acc[31]}
set_db -quiet {inst:Exponent/div/acc_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[31]/q} .original_name {div/acc[31]/q}
set_db -quiet {inst:Exponent/div/acc_reg[32]} .original_name {{div/acc[32]}}
set_db -quiet {inst:Exponent/div/acc_reg[32]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/acc_reg[32]} .single_bit_orig_name {div/acc[32]}
set_db -quiet {inst:Exponent/div/acc_reg[32]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/acc_reg[32]/q} .original_name {div/acc[32]/q}
set_db -quiet {inst:Exponent/div/i_reg[0]} .original_name {{div/i[0]}}
set_db -quiet {inst:Exponent/div/i_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/i_reg[0]} .single_bit_orig_name {div/i[0]}
set_db -quiet {inst:Exponent/div/i_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/i_reg[0]/q} .original_name {div/i[0]/q}
set_db -quiet {inst:Exponent/div/i_reg[1]} .original_name {{div/i[1]}}
set_db -quiet {inst:Exponent/div/i_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/i_reg[1]} .single_bit_orig_name {div/i[1]}
set_db -quiet {inst:Exponent/div/i_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/i_reg[1]/q} .original_name {div/i[1]/q}
set_db -quiet {inst:Exponent/div/i_reg[2]} .original_name {{div/i[2]}}
set_db -quiet {inst:Exponent/div/i_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/i_reg[2]} .single_bit_orig_name {div/i[2]}
set_db -quiet {inst:Exponent/div/i_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/i_reg[2]/q} .original_name {div/i[2]/q}
set_db -quiet {inst:Exponent/div/i_reg[3]} .original_name {{div/i[3]}}
set_db -quiet {inst:Exponent/div/i_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/i_reg[3]} .single_bit_orig_name {div/i[3]}
set_db -quiet {inst:Exponent/div/i_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/i_reg[3]/q} .original_name {div/i[3]/q}
set_db -quiet {inst:Exponent/div/i_reg[4]} .original_name {{div/i[4]}}
set_db -quiet {inst:Exponent/div/i_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div/i_reg[4]} .single_bit_orig_name {div/i[4]}
set_db -quiet {inst:Exponent/div/i_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div/i_reg[4]/q} .original_name {div/i[4]/q}
set_db -quiet module:Exponent/equal_unsigned_22 .logical_hier false
set_db -quiet hinst:Exponent/eq_52_39 .rtlop_info {{} 0 0 0 3 0 63 0 2 1 1 0}
set_db -quiet module:Exponent/add_unsigned_24 .logical_hier false
set_db -quiet hinst:Exponent/add_120_63 .rtlop_info {{} 0 0 0 3 0 7 0 2 1 1 0}
set_db -quiet module:Exponent/mult_unsigned .logical_hier false
set_db -quiet hinst:Exponent/mul_80_28 .rtlop_info {{} 0 0 0 3 0 47 0 2 1 1 0}
set_db -quiet hinst:Exponent/add_108_32 .rtlop_info {{} 0 0 0 3 0 7 0 2 1 1 0}
set_db -quiet module:Exponent/add_unsigned_963 .logical_hier false
set_db -quiet hinst:Exponent/add_118_48 .rtlop_info {{} 0 0 0 3 0 7 0 2 1 1 0}
set_db -quiet module:Exponent/case_box .logical_hier false
set_db -quiet module:Exponent/mux .logical_hier false
set_db -quiet module:Exponent/bmux_967 .logical_hier false
set_db -quiet module:Exponent/case_box_14 .logical_hier false
set_db -quiet module:Exponent/mux_969 .logical_hier false
set_db -quiet module:Exponent/mux_971 .logical_hier false
set_db -quiet module:Exponent/mux_974 .logical_hier false
set_db -quiet module:Exponent/bmux_972 .logical_hier false
set_db -quiet {inst:Exponent/states_reg[0]} .original_name {{states[0]}}
set_db -quiet {inst:Exponent/states_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/states_reg[0]} .single_bit_orig_name {states[0]}
set_db -quiet {inst:Exponent/states_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/states_reg[0]/q} .original_name {states[0]/q}
set_db -quiet {inst:Exponent/states_reg[1]} .original_name {{states[1]}}
set_db -quiet {inst:Exponent/states_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/states_reg[1]} .single_bit_orig_name {states[1]}
set_db -quiet {inst:Exponent/states_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/states_reg[1]/q} .original_name {states[1]/q}
set_db -quiet {inst:Exponent/data_out_reg[0]} .original_name {{data_out[0]}}
set_db -quiet {inst:Exponent/data_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[0]} .single_bit_orig_name {data_out[0]}
set_db -quiet {inst:Exponent/data_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[0]/q} .original_name {data_out[0]/q}
set_db -quiet {inst:Exponent/data_out_reg[1]} .original_name {{data_out[1]}}
set_db -quiet {inst:Exponent/data_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[1]} .single_bit_orig_name {data_out[1]}
set_db -quiet {inst:Exponent/data_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[1]/q} .original_name {data_out[1]/q}
set_db -quiet {inst:Exponent/data_out_reg[2]} .original_name {{data_out[2]}}
set_db -quiet {inst:Exponent/data_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[2]} .single_bit_orig_name {data_out[2]}
set_db -quiet {inst:Exponent/data_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[2]/q} .original_name {data_out[2]/q}
set_db -quiet {inst:Exponent/data_out_reg[3]} .original_name {{data_out[3]}}
set_db -quiet {inst:Exponent/data_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[3]} .single_bit_orig_name {data_out[3]}
set_db -quiet {inst:Exponent/data_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[3]/q} .original_name {data_out[3]/q}
set_db -quiet {inst:Exponent/data_out_reg[4]} .original_name {{data_out[4]}}
set_db -quiet {inst:Exponent/data_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[4]} .single_bit_orig_name {data_out[4]}
set_db -quiet {inst:Exponent/data_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[4]/q} .original_name {data_out[4]/q}
set_db -quiet {inst:Exponent/data_out_reg[5]} .original_name {{data_out[5]}}
set_db -quiet {inst:Exponent/data_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[5]} .single_bit_orig_name {data_out[5]}
set_db -quiet {inst:Exponent/data_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[5]/q} .original_name {data_out[5]/q}
set_db -quiet {inst:Exponent/data_out_reg[6]} .original_name {{data_out[6]}}
set_db -quiet {inst:Exponent/data_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[6]} .single_bit_orig_name {data_out[6]}
set_db -quiet {inst:Exponent/data_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[6]/q} .original_name {data_out[6]/q}
set_db -quiet {inst:Exponent/data_out_reg[7]} .original_name {{data_out[7]}}
set_db -quiet {inst:Exponent/data_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[7]} .single_bit_orig_name {data_out[7]}
set_db -quiet {inst:Exponent/data_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[7]/q} .original_name {data_out[7]/q}
set_db -quiet {inst:Exponent/data_out_reg[8]} .original_name {{data_out[8]}}
set_db -quiet {inst:Exponent/data_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[8]} .single_bit_orig_name {data_out[8]}
set_db -quiet {inst:Exponent/data_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[8]/q} .original_name {data_out[8]/q}
set_db -quiet {inst:Exponent/data_out_reg[9]} .original_name {{data_out[9]}}
set_db -quiet {inst:Exponent/data_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[9]} .single_bit_orig_name {data_out[9]}
set_db -quiet {inst:Exponent/data_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[9]/q} .original_name {data_out[9]/q}
set_db -quiet {inst:Exponent/data_out_reg[10]} .original_name {{data_out[10]}}
set_db -quiet {inst:Exponent/data_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[10]} .single_bit_orig_name {data_out[10]}
set_db -quiet {inst:Exponent/data_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[10]/q} .original_name {data_out[10]/q}
set_db -quiet {inst:Exponent/data_out_reg[11]} .original_name {{data_out[11]}}
set_db -quiet {inst:Exponent/data_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[11]} .single_bit_orig_name {data_out[11]}
set_db -quiet {inst:Exponent/data_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[11]/q} .original_name {data_out[11]/q}
set_db -quiet {inst:Exponent/data_out_reg[12]} .original_name {{data_out[12]}}
set_db -quiet {inst:Exponent/data_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[12]} .single_bit_orig_name {data_out[12]}
set_db -quiet {inst:Exponent/data_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[12]/q} .original_name {data_out[12]/q}
set_db -quiet {inst:Exponent/data_out_reg[13]} .original_name {{data_out[13]}}
set_db -quiet {inst:Exponent/data_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[13]} .single_bit_orig_name {data_out[13]}
set_db -quiet {inst:Exponent/data_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[13]/q} .original_name {data_out[13]/q}
set_db -quiet {inst:Exponent/data_out_reg[14]} .original_name {{data_out[14]}}
set_db -quiet {inst:Exponent/data_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[14]} .single_bit_orig_name {data_out[14]}
set_db -quiet {inst:Exponent/data_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[14]/q} .original_name {data_out[14]/q}
set_db -quiet {inst:Exponent/data_out_reg[15]} .original_name {{data_out[15]}}
set_db -quiet {inst:Exponent/data_out_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[15]} .single_bit_orig_name {data_out[15]}
set_db -quiet {inst:Exponent/data_out_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[15]/q} .original_name {data_out[15]/q}
set_db -quiet {inst:Exponent/data_out_reg[16]} .original_name {{data_out[16]}}
set_db -quiet {inst:Exponent/data_out_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[16]} .single_bit_orig_name {data_out[16]}
set_db -quiet {inst:Exponent/data_out_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[16]/q} .original_name {data_out[16]/q}
set_db -quiet {inst:Exponent/data_out_reg[17]} .original_name {{data_out[17]}}
set_db -quiet {inst:Exponent/data_out_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[17]} .single_bit_orig_name {data_out[17]}
set_db -quiet {inst:Exponent/data_out_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[17]/q} .original_name {data_out[17]/q}
set_db -quiet {inst:Exponent/data_out_reg[18]} .original_name {{data_out[18]}}
set_db -quiet {inst:Exponent/data_out_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[18]} .single_bit_orig_name {data_out[18]}
set_db -quiet {inst:Exponent/data_out_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[18]/q} .original_name {data_out[18]/q}
set_db -quiet {inst:Exponent/data_out_reg[19]} .original_name {{data_out[19]}}
set_db -quiet {inst:Exponent/data_out_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[19]} .single_bit_orig_name {data_out[19]}
set_db -quiet {inst:Exponent/data_out_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[19]/q} .original_name {data_out[19]/q}
set_db -quiet {inst:Exponent/data_out_reg[20]} .original_name {{data_out[20]}}
set_db -quiet {inst:Exponent/data_out_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[20]} .single_bit_orig_name {data_out[20]}
set_db -quiet {inst:Exponent/data_out_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[20]/q} .original_name {data_out[20]/q}
set_db -quiet {inst:Exponent/data_out_reg[21]} .original_name {{data_out[21]}}
set_db -quiet {inst:Exponent/data_out_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[21]} .single_bit_orig_name {data_out[21]}
set_db -quiet {inst:Exponent/data_out_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[21]/q} .original_name {data_out[21]/q}
set_db -quiet {inst:Exponent/data_out_reg[22]} .original_name {{data_out[22]}}
set_db -quiet {inst:Exponent/data_out_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[22]} .single_bit_orig_name {data_out[22]}
set_db -quiet {inst:Exponent/data_out_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[22]/q} .original_name {data_out[22]/q}
set_db -quiet {inst:Exponent/data_out_reg[23]} .original_name {{data_out[23]}}
set_db -quiet {inst:Exponent/data_out_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[23]} .single_bit_orig_name {data_out[23]}
set_db -quiet {inst:Exponent/data_out_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[23]/q} .original_name {data_out[23]/q}
set_db -quiet {inst:Exponent/data_out_reg[24]} .original_name {{data_out[24]}}
set_db -quiet {inst:Exponent/data_out_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[24]} .single_bit_orig_name {data_out[24]}
set_db -quiet {inst:Exponent/data_out_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[24]/q} .original_name {data_out[24]/q}
set_db -quiet {inst:Exponent/data_out_reg[25]} .original_name {{data_out[25]}}
set_db -quiet {inst:Exponent/data_out_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[25]} .single_bit_orig_name {data_out[25]}
set_db -quiet {inst:Exponent/data_out_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[25]/q} .original_name {data_out[25]/q}
set_db -quiet {inst:Exponent/data_out_reg[26]} .original_name {{data_out[26]}}
set_db -quiet {inst:Exponent/data_out_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[26]} .single_bit_orig_name {data_out[26]}
set_db -quiet {inst:Exponent/data_out_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[26]/q} .original_name {data_out[26]/q}
set_db -quiet {inst:Exponent/data_out_reg[27]} .original_name {{data_out[27]}}
set_db -quiet {inst:Exponent/data_out_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[27]} .single_bit_orig_name {data_out[27]}
set_db -quiet {inst:Exponent/data_out_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[27]/q} .original_name {data_out[27]/q}
set_db -quiet {inst:Exponent/data_out_reg[28]} .original_name {{data_out[28]}}
set_db -quiet {inst:Exponent/data_out_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[28]} .single_bit_orig_name {data_out[28]}
set_db -quiet {inst:Exponent/data_out_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[28]/q} .original_name {data_out[28]/q}
set_db -quiet {inst:Exponent/data_out_reg[29]} .original_name {{data_out[29]}}
set_db -quiet {inst:Exponent/data_out_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[29]} .single_bit_orig_name {data_out[29]}
set_db -quiet {inst:Exponent/data_out_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[29]/q} .original_name {data_out[29]/q}
set_db -quiet {inst:Exponent/data_out_reg[30]} .original_name {{data_out[30]}}
set_db -quiet {inst:Exponent/data_out_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[30]} .single_bit_orig_name {data_out[30]}
set_db -quiet {inst:Exponent/data_out_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[30]/q} .original_name {data_out[30]/q}
set_db -quiet {inst:Exponent/data_out_reg[31]} .original_name {{data_out[31]}}
set_db -quiet {inst:Exponent/data_out_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[31]} .single_bit_orig_name {data_out[31]}
set_db -quiet {inst:Exponent/data_out_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[31]/q} .original_name {data_out[31]/q}
set_db -quiet {inst:Exponent/data_out_reg[32]} .original_name {{data_out[32]}}
set_db -quiet {inst:Exponent/data_out_reg[32]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[32]} .single_bit_orig_name {data_out[32]}
set_db -quiet {inst:Exponent/data_out_reg[32]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[32]/q} .original_name {data_out[32]/q}
set_db -quiet {inst:Exponent/data_out_reg[33]} .original_name {{data_out[33]}}
set_db -quiet {inst:Exponent/data_out_reg[33]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[33]} .single_bit_orig_name {data_out[33]}
set_db -quiet {inst:Exponent/data_out_reg[33]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[33]/q} .original_name {data_out[33]/q}
set_db -quiet {inst:Exponent/data_out_reg[34]} .original_name {{data_out[34]}}
set_db -quiet {inst:Exponent/data_out_reg[34]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[34]} .single_bit_orig_name {data_out[34]}
set_db -quiet {inst:Exponent/data_out_reg[34]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[34]/q} .original_name {data_out[34]/q}
set_db -quiet {inst:Exponent/data_out_reg[35]} .original_name {{data_out[35]}}
set_db -quiet {inst:Exponent/data_out_reg[35]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[35]} .single_bit_orig_name {data_out[35]}
set_db -quiet {inst:Exponent/data_out_reg[35]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[35]/q} .original_name {data_out[35]/q}
set_db -quiet {inst:Exponent/data_out_reg[36]} .original_name {{data_out[36]}}
set_db -quiet {inst:Exponent/data_out_reg[36]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[36]} .single_bit_orig_name {data_out[36]}
set_db -quiet {inst:Exponent/data_out_reg[36]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[36]/q} .original_name {data_out[36]/q}
set_db -quiet {inst:Exponent/data_out_reg[37]} .original_name {{data_out[37]}}
set_db -quiet {inst:Exponent/data_out_reg[37]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[37]} .single_bit_orig_name {data_out[37]}
set_db -quiet {inst:Exponent/data_out_reg[37]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[37]/q} .original_name {data_out[37]/q}
set_db -quiet {inst:Exponent/data_out_reg[38]} .original_name {{data_out[38]}}
set_db -quiet {inst:Exponent/data_out_reg[38]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[38]} .single_bit_orig_name {data_out[38]}
set_db -quiet {inst:Exponent/data_out_reg[38]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[38]/q} .original_name {data_out[38]/q}
set_db -quiet {inst:Exponent/data_out_reg[39]} .original_name {{data_out[39]}}
set_db -quiet {inst:Exponent/data_out_reg[39]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[39]} .single_bit_orig_name {data_out[39]}
set_db -quiet {inst:Exponent/data_out_reg[39]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[39]/q} .original_name {data_out[39]/q}
set_db -quiet {inst:Exponent/data_out_reg[40]} .original_name {{data_out[40]}}
set_db -quiet {inst:Exponent/data_out_reg[40]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[40]} .single_bit_orig_name {data_out[40]}
set_db -quiet {inst:Exponent/data_out_reg[40]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[40]/q} .original_name {data_out[40]/q}
set_db -quiet {inst:Exponent/data_out_reg[41]} .original_name {{data_out[41]}}
set_db -quiet {inst:Exponent/data_out_reg[41]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[41]} .single_bit_orig_name {data_out[41]}
set_db -quiet {inst:Exponent/data_out_reg[41]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[41]/q} .original_name {data_out[41]/q}
set_db -quiet {inst:Exponent/data_out_reg[42]} .original_name {{data_out[42]}}
set_db -quiet {inst:Exponent/data_out_reg[42]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[42]} .single_bit_orig_name {data_out[42]}
set_db -quiet {inst:Exponent/data_out_reg[42]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[42]/q} .original_name {data_out[42]/q}
set_db -quiet {inst:Exponent/data_out_reg[43]} .original_name {{data_out[43]}}
set_db -quiet {inst:Exponent/data_out_reg[43]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[43]} .single_bit_orig_name {data_out[43]}
set_db -quiet {inst:Exponent/data_out_reg[43]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[43]/q} .original_name {data_out[43]/q}
set_db -quiet {inst:Exponent/data_out_reg[44]} .original_name {{data_out[44]}}
set_db -quiet {inst:Exponent/data_out_reg[44]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[44]} .single_bit_orig_name {data_out[44]}
set_db -quiet {inst:Exponent/data_out_reg[44]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[44]/q} .original_name {data_out[44]/q}
set_db -quiet {inst:Exponent/data_out_reg[45]} .original_name {{data_out[45]}}
set_db -quiet {inst:Exponent/data_out_reg[45]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[45]} .single_bit_orig_name {data_out[45]}
set_db -quiet {inst:Exponent/data_out_reg[45]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[45]/q} .original_name {data_out[45]/q}
set_db -quiet {inst:Exponent/data_out_reg[46]} .original_name {{data_out[46]}}
set_db -quiet {inst:Exponent/data_out_reg[46]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[46]} .single_bit_orig_name {data_out[46]}
set_db -quiet {inst:Exponent/data_out_reg[46]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[46]/q} .original_name {data_out[46]/q}
set_db -quiet {inst:Exponent/data_out_reg[47]} .original_name {{data_out[47]}}
set_db -quiet {inst:Exponent/data_out_reg[47]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[47]} .single_bit_orig_name {data_out[47]}
set_db -quiet {inst:Exponent/data_out_reg[47]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[47]/q} .original_name {data_out[47]/q}
set_db -quiet {inst:Exponent/data_out_reg[48]} .original_name {{data_out[48]}}
set_db -quiet {inst:Exponent/data_out_reg[48]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[48]} .single_bit_orig_name {data_out[48]}
set_db -quiet {inst:Exponent/data_out_reg[48]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[48]/q} .original_name {data_out[48]/q}
set_db -quiet {inst:Exponent/data_out_reg[49]} .original_name {{data_out[49]}}
set_db -quiet {inst:Exponent/data_out_reg[49]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[49]} .single_bit_orig_name {data_out[49]}
set_db -quiet {inst:Exponent/data_out_reg[49]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[49]/q} .original_name {data_out[49]/q}
set_db -quiet {inst:Exponent/data_out_reg[50]} .original_name {{data_out[50]}}
set_db -quiet {inst:Exponent/data_out_reg[50]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[50]} .single_bit_orig_name {data_out[50]}
set_db -quiet {inst:Exponent/data_out_reg[50]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[50]/q} .original_name {data_out[50]/q}
set_db -quiet {inst:Exponent/data_out_reg[51]} .original_name {{data_out[51]}}
set_db -quiet {inst:Exponent/data_out_reg[51]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[51]} .single_bit_orig_name {data_out[51]}
set_db -quiet {inst:Exponent/data_out_reg[51]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[51]/q} .original_name {data_out[51]/q}
set_db -quiet {inst:Exponent/data_out_reg[52]} .original_name {{data_out[52]}}
set_db -quiet {inst:Exponent/data_out_reg[52]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[52]} .single_bit_orig_name {data_out[52]}
set_db -quiet {inst:Exponent/data_out_reg[52]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[52]/q} .original_name {data_out[52]/q}
set_db -quiet {inst:Exponent/data_out_reg[53]} .original_name {{data_out[53]}}
set_db -quiet {inst:Exponent/data_out_reg[53]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[53]} .single_bit_orig_name {data_out[53]}
set_db -quiet {inst:Exponent/data_out_reg[53]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[53]/q} .original_name {data_out[53]/q}
set_db -quiet {inst:Exponent/data_out_reg[54]} .original_name {{data_out[54]}}
set_db -quiet {inst:Exponent/data_out_reg[54]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[54]} .single_bit_orig_name {data_out[54]}
set_db -quiet {inst:Exponent/data_out_reg[54]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[54]/q} .original_name {data_out[54]/q}
set_db -quiet {inst:Exponent/data_out_reg[55]} .original_name {{data_out[55]}}
set_db -quiet {inst:Exponent/data_out_reg[55]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[55]} .single_bit_orig_name {data_out[55]}
set_db -quiet {inst:Exponent/data_out_reg[55]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[55]/q} .original_name {data_out[55]/q}
set_db -quiet {inst:Exponent/data_out_reg[56]} .original_name {{data_out[56]}}
set_db -quiet {inst:Exponent/data_out_reg[56]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[56]} .single_bit_orig_name {data_out[56]}
set_db -quiet {inst:Exponent/data_out_reg[56]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[56]/q} .original_name {data_out[56]/q}
set_db -quiet {inst:Exponent/data_out_reg[57]} .original_name {{data_out[57]}}
set_db -quiet {inst:Exponent/data_out_reg[57]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[57]} .single_bit_orig_name {data_out[57]}
set_db -quiet {inst:Exponent/data_out_reg[57]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[57]/q} .original_name {data_out[57]/q}
set_db -quiet {inst:Exponent/data_out_reg[58]} .original_name {{data_out[58]}}
set_db -quiet {inst:Exponent/data_out_reg[58]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[58]} .single_bit_orig_name {data_out[58]}
set_db -quiet {inst:Exponent/data_out_reg[58]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[58]/q} .original_name {data_out[58]/q}
set_db -quiet {inst:Exponent/data_out_reg[59]} .original_name {{data_out[59]}}
set_db -quiet {inst:Exponent/data_out_reg[59]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[59]} .single_bit_orig_name {data_out[59]}
set_db -quiet {inst:Exponent/data_out_reg[59]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[59]/q} .original_name {data_out[59]/q}
set_db -quiet {inst:Exponent/data_out_reg[60]} .original_name {{data_out[60]}}
set_db -quiet {inst:Exponent/data_out_reg[60]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[60]} .single_bit_orig_name {data_out[60]}
set_db -quiet {inst:Exponent/data_out_reg[60]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[60]/q} .original_name {data_out[60]/q}
set_db -quiet {inst:Exponent/data_out_reg[61]} .original_name {{data_out[61]}}
set_db -quiet {inst:Exponent/data_out_reg[61]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[61]} .single_bit_orig_name {data_out[61]}
set_db -quiet {inst:Exponent/data_out_reg[61]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[61]/q} .original_name {data_out[61]/q}
set_db -quiet {inst:Exponent/data_out_reg[62]} .original_name {{data_out[62]}}
set_db -quiet {inst:Exponent/data_out_reg[62]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[62]} .single_bit_orig_name {data_out[62]}
set_db -quiet {inst:Exponent/data_out_reg[62]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[62]/q} .original_name {data_out[62]/q}
set_db -quiet {inst:Exponent/data_out_reg[63]} .original_name {{data_out[63]}}
set_db -quiet {inst:Exponent/data_out_reg[63]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/data_out_reg[63]} .single_bit_orig_name {data_out[63]}
set_db -quiet {inst:Exponent/data_out_reg[63]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/data_out_reg[63]/q} .original_name {data_out[63]/q}
set_db -quiet inst:Exponent/busy_reg .original_name busy
set_db -quiet inst:Exponent/busy_reg .orig_hdl_instantiated false
set_db -quiet inst:Exponent/busy_reg .single_bit_orig_name busy
set_db -quiet inst:Exponent/busy_reg .gint_phase_inversion false
set_db -quiet pin:Exponent/busy_reg/q .original_name busy/q
set_db -quiet inst:Exponent/done_reg .original_name done
set_db -quiet inst:Exponent/done_reg .orig_hdl_instantiated false
set_db -quiet inst:Exponent/done_reg .single_bit_orig_name done
set_db -quiet inst:Exponent/done_reg .gint_phase_inversion false
set_db -quiet pin:Exponent/done_reg/q .original_name done/q
set_db -quiet inst:Exponent/div_start_reg .original_name div_start
set_db -quiet inst:Exponent/div_start_reg .orig_hdl_instantiated false
set_db -quiet inst:Exponent/div_start_reg .single_bit_orig_name div_start
set_db -quiet inst:Exponent/div_start_reg .gint_phase_inversion false
set_db -quiet pin:Exponent/div_start_reg/q .original_name div_start/q
set_db -quiet {inst:Exponent/dinput_reg[0]} .original_name {{dinput[0]}}
set_db -quiet {inst:Exponent/dinput_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[0]} .single_bit_orig_name {dinput[0]}
set_db -quiet {inst:Exponent/dinput_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[0]/q} .original_name {dinput[0]/q}
set_db -quiet {inst:Exponent/dinput_reg[1]} .original_name {{dinput[1]}}
set_db -quiet {inst:Exponent/dinput_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[1]} .single_bit_orig_name {dinput[1]}
set_db -quiet {inst:Exponent/dinput_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[1]/q} .original_name {dinput[1]/q}
set_db -quiet {inst:Exponent/dinput_reg[2]} .original_name {{dinput[2]}}
set_db -quiet {inst:Exponent/dinput_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[2]} .single_bit_orig_name {dinput[2]}
set_db -quiet {inst:Exponent/dinput_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[2]/q} .original_name {dinput[2]/q}
set_db -quiet {inst:Exponent/dinput_reg[3]} .original_name {{dinput[3]}}
set_db -quiet {inst:Exponent/dinput_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[3]} .single_bit_orig_name {dinput[3]}
set_db -quiet {inst:Exponent/dinput_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[3]/q} .original_name {dinput[3]/q}
set_db -quiet {inst:Exponent/dinput_reg[4]} .original_name {{dinput[4]}}
set_db -quiet {inst:Exponent/dinput_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[4]} .single_bit_orig_name {dinput[4]}
set_db -quiet {inst:Exponent/dinput_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[4]/q} .original_name {dinput[4]/q}
set_db -quiet {inst:Exponent/dinput_reg[5]} .original_name {{dinput[5]}}
set_db -quiet {inst:Exponent/dinput_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[5]} .single_bit_orig_name {dinput[5]}
set_db -quiet {inst:Exponent/dinput_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[5]/q} .original_name {dinput[5]/q}
set_db -quiet {inst:Exponent/dinput_reg[6]} .original_name {{dinput[6]}}
set_db -quiet {inst:Exponent/dinput_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[6]} .single_bit_orig_name {dinput[6]}
set_db -quiet {inst:Exponent/dinput_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[6]/q} .original_name {dinput[6]/q}
set_db -quiet {inst:Exponent/dinput_reg[7]} .original_name {{dinput[7]}}
set_db -quiet {inst:Exponent/dinput_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[7]} .single_bit_orig_name {dinput[7]}
set_db -quiet {inst:Exponent/dinput_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[7]/q} .original_name {dinput[7]/q}
set_db -quiet {inst:Exponent/dinput_reg[8]} .original_name {{dinput[8]}}
set_db -quiet {inst:Exponent/dinput_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[8]} .single_bit_orig_name {dinput[8]}
set_db -quiet {inst:Exponent/dinput_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[8]/q} .original_name {dinput[8]/q}
set_db -quiet {inst:Exponent/dinput_reg[9]} .original_name {{dinput[9]}}
set_db -quiet {inst:Exponent/dinput_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[9]} .single_bit_orig_name {dinput[9]}
set_db -quiet {inst:Exponent/dinput_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[9]/q} .original_name {dinput[9]/q}
set_db -quiet {inst:Exponent/dinput_reg[10]} .original_name {{dinput[10]}}
set_db -quiet {inst:Exponent/dinput_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[10]} .single_bit_orig_name {dinput[10]}
set_db -quiet {inst:Exponent/dinput_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[10]/q} .original_name {dinput[10]/q}
set_db -quiet {inst:Exponent/dinput_reg[11]} .original_name {{dinput[11]}}
set_db -quiet {inst:Exponent/dinput_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[11]} .single_bit_orig_name {dinput[11]}
set_db -quiet {inst:Exponent/dinput_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[11]/q} .original_name {dinput[11]/q}
set_db -quiet {inst:Exponent/dinput_reg[12]} .original_name {{dinput[12]}}
set_db -quiet {inst:Exponent/dinput_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[12]} .single_bit_orig_name {dinput[12]}
set_db -quiet {inst:Exponent/dinput_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[12]/q} .original_name {dinput[12]/q}
set_db -quiet {inst:Exponent/dinput_reg[13]} .original_name {{dinput[13]}}
set_db -quiet {inst:Exponent/dinput_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[13]} .single_bit_orig_name {dinput[13]}
set_db -quiet {inst:Exponent/dinput_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[13]/q} .original_name {dinput[13]/q}
set_db -quiet {inst:Exponent/dinput_reg[14]} .original_name {{dinput[14]}}
set_db -quiet {inst:Exponent/dinput_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[14]} .single_bit_orig_name {dinput[14]}
set_db -quiet {inst:Exponent/dinput_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[14]/q} .original_name {dinput[14]/q}
set_db -quiet {inst:Exponent/dinput_reg[15]} .original_name {{dinput[15]}}
set_db -quiet {inst:Exponent/dinput_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[15]} .single_bit_orig_name {dinput[15]}
set_db -quiet {inst:Exponent/dinput_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[15]/q} .original_name {dinput[15]/q}
set_db -quiet {inst:Exponent/dinput_reg[16]} .original_name {{dinput[16]}}
set_db -quiet {inst:Exponent/dinput_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[16]} .single_bit_orig_name {dinput[16]}
set_db -quiet {inst:Exponent/dinput_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[16]/q} .original_name {dinput[16]/q}
set_db -quiet {inst:Exponent/dinput_reg[17]} .original_name {{dinput[17]}}
set_db -quiet {inst:Exponent/dinput_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[17]} .single_bit_orig_name {dinput[17]}
set_db -quiet {inst:Exponent/dinput_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[17]/q} .original_name {dinput[17]/q}
set_db -quiet {inst:Exponent/dinput_reg[18]} .original_name {{dinput[18]}}
set_db -quiet {inst:Exponent/dinput_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[18]} .single_bit_orig_name {dinput[18]}
set_db -quiet {inst:Exponent/dinput_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[18]/q} .original_name {dinput[18]/q}
set_db -quiet {inst:Exponent/dinput_reg[19]} .original_name {{dinput[19]}}
set_db -quiet {inst:Exponent/dinput_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[19]} .single_bit_orig_name {dinput[19]}
set_db -quiet {inst:Exponent/dinput_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[19]/q} .original_name {dinput[19]/q}
set_db -quiet {inst:Exponent/dinput_reg[20]} .original_name {{dinput[20]}}
set_db -quiet {inst:Exponent/dinput_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[20]} .single_bit_orig_name {dinput[20]}
set_db -quiet {inst:Exponent/dinput_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[20]/q} .original_name {dinput[20]/q}
set_db -quiet {inst:Exponent/dinput_reg[21]} .original_name {{dinput[21]}}
set_db -quiet {inst:Exponent/dinput_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[21]} .single_bit_orig_name {dinput[21]}
set_db -quiet {inst:Exponent/dinput_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[21]/q} .original_name {dinput[21]/q}
set_db -quiet {inst:Exponent/dinput_reg[22]} .original_name {{dinput[22]}}
set_db -quiet {inst:Exponent/dinput_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[22]} .single_bit_orig_name {dinput[22]}
set_db -quiet {inst:Exponent/dinput_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[22]/q} .original_name {dinput[22]/q}
set_db -quiet {inst:Exponent/dinput_reg[23]} .original_name {{dinput[23]}}
set_db -quiet {inst:Exponent/dinput_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[23]} .single_bit_orig_name {dinput[23]}
set_db -quiet {inst:Exponent/dinput_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[23]/q} .original_name {dinput[23]/q}
set_db -quiet {inst:Exponent/dinput_reg[24]} .original_name {{dinput[24]}}
set_db -quiet {inst:Exponent/dinput_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[24]} .single_bit_orig_name {dinput[24]}
set_db -quiet {inst:Exponent/dinput_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[24]/q} .original_name {dinput[24]/q}
set_db -quiet {inst:Exponent/dinput_reg[25]} .original_name {{dinput[25]}}
set_db -quiet {inst:Exponent/dinput_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[25]} .single_bit_orig_name {dinput[25]}
set_db -quiet {inst:Exponent/dinput_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[25]/q} .original_name {dinput[25]/q}
set_db -quiet {inst:Exponent/dinput_reg[26]} .original_name {{dinput[26]}}
set_db -quiet {inst:Exponent/dinput_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[26]} .single_bit_orig_name {dinput[26]}
set_db -quiet {inst:Exponent/dinput_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[26]/q} .original_name {dinput[26]/q}
set_db -quiet {inst:Exponent/dinput_reg[27]} .original_name {{dinput[27]}}
set_db -quiet {inst:Exponent/dinput_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[27]} .single_bit_orig_name {dinput[27]}
set_db -quiet {inst:Exponent/dinput_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[27]/q} .original_name {dinput[27]/q}
set_db -quiet {inst:Exponent/dinput_reg[28]} .original_name {{dinput[28]}}
set_db -quiet {inst:Exponent/dinput_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[28]} .single_bit_orig_name {dinput[28]}
set_db -quiet {inst:Exponent/dinput_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[28]/q} .original_name {dinput[28]/q}
set_db -quiet {inst:Exponent/dinput_reg[29]} .original_name {{dinput[29]}}
set_db -quiet {inst:Exponent/dinput_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[29]} .single_bit_orig_name {dinput[29]}
set_db -quiet {inst:Exponent/dinput_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[29]/q} .original_name {dinput[29]/q}
set_db -quiet {inst:Exponent/dinput_reg[30]} .original_name {{dinput[30]}}
set_db -quiet {inst:Exponent/dinput_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[30]} .single_bit_orig_name {dinput[30]}
set_db -quiet {inst:Exponent/dinput_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[30]/q} .original_name {dinput[30]/q}
set_db -quiet {inst:Exponent/dinput_reg[31]} .original_name {{dinput[31]}}
set_db -quiet {inst:Exponent/dinput_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/dinput_reg[31]} .single_bit_orig_name {dinput[31]}
set_db -quiet {inst:Exponent/dinput_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/dinput_reg[31]/q} .original_name {dinput[31]/q}
set_db -quiet {inst:Exponent/x2_reg[0]} .original_name {{x2[0]}}
set_db -quiet {inst:Exponent/x2_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[0]} .single_bit_orig_name {x2[0]}
set_db -quiet {inst:Exponent/x2_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[0]/q} .original_name {x2[0]/q}
set_db -quiet {inst:Exponent/x2_reg[1]} .original_name {{x2[1]}}
set_db -quiet {inst:Exponent/x2_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[1]} .single_bit_orig_name {x2[1]}
set_db -quiet {inst:Exponent/x2_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[1]/q} .original_name {x2[1]/q}
set_db -quiet {inst:Exponent/x2_reg[2]} .original_name {{x2[2]}}
set_db -quiet {inst:Exponent/x2_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[2]} .single_bit_orig_name {x2[2]}
set_db -quiet {inst:Exponent/x2_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[2]/q} .original_name {x2[2]/q}
set_db -quiet {inst:Exponent/x2_reg[3]} .original_name {{x2[3]}}
set_db -quiet {inst:Exponent/x2_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[3]} .single_bit_orig_name {x2[3]}
set_db -quiet {inst:Exponent/x2_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[3]/q} .original_name {x2[3]/q}
set_db -quiet {inst:Exponent/x2_reg[4]} .original_name {{x2[4]}}
set_db -quiet {inst:Exponent/x2_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[4]} .single_bit_orig_name {x2[4]}
set_db -quiet {inst:Exponent/x2_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[4]/q} .original_name {x2[4]/q}
set_db -quiet {inst:Exponent/x2_reg[5]} .original_name {{x2[5]}}
set_db -quiet {inst:Exponent/x2_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[5]} .single_bit_orig_name {x2[5]}
set_db -quiet {inst:Exponent/x2_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[5]/q} .original_name {x2[5]/q}
set_db -quiet {inst:Exponent/x2_reg[6]} .original_name {{x2[6]}}
set_db -quiet {inst:Exponent/x2_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[6]} .single_bit_orig_name {x2[6]}
set_db -quiet {inst:Exponent/x2_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[6]/q} .original_name {x2[6]/q}
set_db -quiet {inst:Exponent/x2_reg[7]} .original_name {{x2[7]}}
set_db -quiet {inst:Exponent/x2_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[7]} .single_bit_orig_name {x2[7]}
set_db -quiet {inst:Exponent/x2_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[7]/q} .original_name {x2[7]/q}
set_db -quiet {inst:Exponent/x2_reg[8]} .original_name {{x2[8]}}
set_db -quiet {inst:Exponent/x2_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[8]} .single_bit_orig_name {x2[8]}
set_db -quiet {inst:Exponent/x2_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[8]/q} .original_name {x2[8]/q}
set_db -quiet {inst:Exponent/x2_reg[9]} .original_name {{x2[9]}}
set_db -quiet {inst:Exponent/x2_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[9]} .single_bit_orig_name {x2[9]}
set_db -quiet {inst:Exponent/x2_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[9]/q} .original_name {x2[9]/q}
set_db -quiet {inst:Exponent/x2_reg[10]} .original_name {{x2[10]}}
set_db -quiet {inst:Exponent/x2_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[10]} .single_bit_orig_name {x2[10]}
set_db -quiet {inst:Exponent/x2_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[10]/q} .original_name {x2[10]/q}
set_db -quiet {inst:Exponent/x2_reg[11]} .original_name {{x2[11]}}
set_db -quiet {inst:Exponent/x2_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[11]} .single_bit_orig_name {x2[11]}
set_db -quiet {inst:Exponent/x2_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[11]/q} .original_name {x2[11]/q}
set_db -quiet {inst:Exponent/x2_reg[12]} .original_name {{x2[12]}}
set_db -quiet {inst:Exponent/x2_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[12]} .single_bit_orig_name {x2[12]}
set_db -quiet {inst:Exponent/x2_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[12]/q} .original_name {x2[12]/q}
set_db -quiet {inst:Exponent/x2_reg[13]} .original_name {{x2[13]}}
set_db -quiet {inst:Exponent/x2_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[13]} .single_bit_orig_name {x2[13]}
set_db -quiet {inst:Exponent/x2_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[13]/q} .original_name {x2[13]/q}
set_db -quiet {inst:Exponent/x2_reg[14]} .original_name {{x2[14]}}
set_db -quiet {inst:Exponent/x2_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[14]} .single_bit_orig_name {x2[14]}
set_db -quiet {inst:Exponent/x2_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[14]/q} .original_name {x2[14]/q}
set_db -quiet {inst:Exponent/x2_reg[15]} .original_name {{x2[15]}}
set_db -quiet {inst:Exponent/x2_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[15]} .single_bit_orig_name {x2[15]}
set_db -quiet {inst:Exponent/x2_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[15]/q} .original_name {x2[15]/q}
set_db -quiet {inst:Exponent/x2_reg[16]} .original_name {{x2[16]}}
set_db -quiet {inst:Exponent/x2_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[16]} .single_bit_orig_name {x2[16]}
set_db -quiet {inst:Exponent/x2_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[16]/q} .original_name {x2[16]/q}
set_db -quiet {inst:Exponent/x2_reg[17]} .original_name {{x2[17]}}
set_db -quiet {inst:Exponent/x2_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[17]} .single_bit_orig_name {x2[17]}
set_db -quiet {inst:Exponent/x2_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[17]/q} .original_name {x2[17]/q}
set_db -quiet {inst:Exponent/x2_reg[18]} .original_name {{x2[18]}}
set_db -quiet {inst:Exponent/x2_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[18]} .single_bit_orig_name {x2[18]}
set_db -quiet {inst:Exponent/x2_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[18]/q} .original_name {x2[18]/q}
set_db -quiet {inst:Exponent/x2_reg[19]} .original_name {{x2[19]}}
set_db -quiet {inst:Exponent/x2_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[19]} .single_bit_orig_name {x2[19]}
set_db -quiet {inst:Exponent/x2_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[19]/q} .original_name {x2[19]/q}
set_db -quiet {inst:Exponent/x2_reg[20]} .original_name {{x2[20]}}
set_db -quiet {inst:Exponent/x2_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[20]} .single_bit_orig_name {x2[20]}
set_db -quiet {inst:Exponent/x2_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[20]/q} .original_name {x2[20]/q}
set_db -quiet {inst:Exponent/x2_reg[21]} .original_name {{x2[21]}}
set_db -quiet {inst:Exponent/x2_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[21]} .single_bit_orig_name {x2[21]}
set_db -quiet {inst:Exponent/x2_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[21]/q} .original_name {x2[21]/q}
set_db -quiet {inst:Exponent/x2_reg[22]} .original_name {{x2[22]}}
set_db -quiet {inst:Exponent/x2_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[22]} .single_bit_orig_name {x2[22]}
set_db -quiet {inst:Exponent/x2_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[22]/q} .original_name {x2[22]/q}
set_db -quiet {inst:Exponent/x2_reg[23]} .original_name {{x2[23]}}
set_db -quiet {inst:Exponent/x2_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[23]} .single_bit_orig_name {x2[23]}
set_db -quiet {inst:Exponent/x2_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[23]/q} .original_name {x2[23]/q}
set_db -quiet {inst:Exponent/x2_reg[24]} .original_name {{x2[24]}}
set_db -quiet {inst:Exponent/x2_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[24]} .single_bit_orig_name {x2[24]}
set_db -quiet {inst:Exponent/x2_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[24]/q} .original_name {x2[24]/q}
set_db -quiet {inst:Exponent/x2_reg[25]} .original_name {{x2[25]}}
set_db -quiet {inst:Exponent/x2_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[25]} .single_bit_orig_name {x2[25]}
set_db -quiet {inst:Exponent/x2_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[25]/q} .original_name {x2[25]/q}
set_db -quiet {inst:Exponent/x2_reg[26]} .original_name {{x2[26]}}
set_db -quiet {inst:Exponent/x2_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[26]} .single_bit_orig_name {x2[26]}
set_db -quiet {inst:Exponent/x2_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[26]/q} .original_name {x2[26]/q}
set_db -quiet {inst:Exponent/x2_reg[27]} .original_name {{x2[27]}}
set_db -quiet {inst:Exponent/x2_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[27]} .single_bit_orig_name {x2[27]}
set_db -quiet {inst:Exponent/x2_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[27]/q} .original_name {x2[27]/q}
set_db -quiet {inst:Exponent/x2_reg[28]} .original_name {{x2[28]}}
set_db -quiet {inst:Exponent/x2_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[28]} .single_bit_orig_name {x2[28]}
set_db -quiet {inst:Exponent/x2_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[28]/q} .original_name {x2[28]/q}
set_db -quiet {inst:Exponent/x2_reg[29]} .original_name {{x2[29]}}
set_db -quiet {inst:Exponent/x2_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[29]} .single_bit_orig_name {x2[29]}
set_db -quiet {inst:Exponent/x2_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[29]/q} .original_name {x2[29]/q}
set_db -quiet {inst:Exponent/x2_reg[30]} .original_name {{x2[30]}}
set_db -quiet {inst:Exponent/x2_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[30]} .single_bit_orig_name {x2[30]}
set_db -quiet {inst:Exponent/x2_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[30]/q} .original_name {x2[30]/q}
set_db -quiet {inst:Exponent/x2_reg[31]} .original_name {{x2[31]}}
set_db -quiet {inst:Exponent/x2_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x2_reg[31]} .single_bit_orig_name {x2[31]}
set_db -quiet {inst:Exponent/x2_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x2_reg[31]/q} .original_name {x2[31]/q}
set_db -quiet {inst:Exponent/x_pow_reg[0]} .original_name {{x_pow[0]}}
set_db -quiet {inst:Exponent/x_pow_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[0]} .single_bit_orig_name {x_pow[0]}
set_db -quiet {inst:Exponent/x_pow_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[0]/q} .original_name {x_pow[0]/q}
set_db -quiet {inst:Exponent/x_pow_reg[1]} .original_name {{x_pow[1]}}
set_db -quiet {inst:Exponent/x_pow_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[1]} .single_bit_orig_name {x_pow[1]}
set_db -quiet {inst:Exponent/x_pow_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[1]/q} .original_name {x_pow[1]/q}
set_db -quiet {inst:Exponent/x_pow_reg[2]} .original_name {{x_pow[2]}}
set_db -quiet {inst:Exponent/x_pow_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[2]} .single_bit_orig_name {x_pow[2]}
set_db -quiet {inst:Exponent/x_pow_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[2]/q} .original_name {x_pow[2]/q}
set_db -quiet {inst:Exponent/x_pow_reg[3]} .original_name {{x_pow[3]}}
set_db -quiet {inst:Exponent/x_pow_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[3]} .single_bit_orig_name {x_pow[3]}
set_db -quiet {inst:Exponent/x_pow_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[3]/q} .original_name {x_pow[3]/q}
set_db -quiet {inst:Exponent/x_pow_reg[4]} .original_name {{x_pow[4]}}
set_db -quiet {inst:Exponent/x_pow_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[4]} .single_bit_orig_name {x_pow[4]}
set_db -quiet {inst:Exponent/x_pow_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[4]/q} .original_name {x_pow[4]/q}
set_db -quiet {inst:Exponent/x_pow_reg[5]} .original_name {{x_pow[5]}}
set_db -quiet {inst:Exponent/x_pow_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[5]} .single_bit_orig_name {x_pow[5]}
set_db -quiet {inst:Exponent/x_pow_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[5]/q} .original_name {x_pow[5]/q}
set_db -quiet {inst:Exponent/x_pow_reg[6]} .original_name {{x_pow[6]}}
set_db -quiet {inst:Exponent/x_pow_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[6]} .single_bit_orig_name {x_pow[6]}
set_db -quiet {inst:Exponent/x_pow_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[6]/q} .original_name {x_pow[6]/q}
set_db -quiet {inst:Exponent/x_pow_reg[7]} .original_name {{x_pow[7]}}
set_db -quiet {inst:Exponent/x_pow_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[7]} .single_bit_orig_name {x_pow[7]}
set_db -quiet {inst:Exponent/x_pow_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[7]/q} .original_name {x_pow[7]/q}
set_db -quiet {inst:Exponent/x_pow_reg[8]} .original_name {{x_pow[8]}}
set_db -quiet {inst:Exponent/x_pow_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[8]} .single_bit_orig_name {x_pow[8]}
set_db -quiet {inst:Exponent/x_pow_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[8]/q} .original_name {x_pow[8]/q}
set_db -quiet {inst:Exponent/x_pow_reg[9]} .original_name {{x_pow[9]}}
set_db -quiet {inst:Exponent/x_pow_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[9]} .single_bit_orig_name {x_pow[9]}
set_db -quiet {inst:Exponent/x_pow_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[9]/q} .original_name {x_pow[9]/q}
set_db -quiet {inst:Exponent/x_pow_reg[10]} .original_name {{x_pow[10]}}
set_db -quiet {inst:Exponent/x_pow_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[10]} .single_bit_orig_name {x_pow[10]}
set_db -quiet {inst:Exponent/x_pow_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[10]/q} .original_name {x_pow[10]/q}
set_db -quiet {inst:Exponent/x_pow_reg[11]} .original_name {{x_pow[11]}}
set_db -quiet {inst:Exponent/x_pow_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[11]} .single_bit_orig_name {x_pow[11]}
set_db -quiet {inst:Exponent/x_pow_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[11]/q} .original_name {x_pow[11]/q}
set_db -quiet {inst:Exponent/x_pow_reg[12]} .original_name {{x_pow[12]}}
set_db -quiet {inst:Exponent/x_pow_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[12]} .single_bit_orig_name {x_pow[12]}
set_db -quiet {inst:Exponent/x_pow_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[12]/q} .original_name {x_pow[12]/q}
set_db -quiet {inst:Exponent/x_pow_reg[13]} .original_name {{x_pow[13]}}
set_db -quiet {inst:Exponent/x_pow_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[13]} .single_bit_orig_name {x_pow[13]}
set_db -quiet {inst:Exponent/x_pow_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[13]/q} .original_name {x_pow[13]/q}
set_db -quiet {inst:Exponent/x_pow_reg[14]} .original_name {{x_pow[14]}}
set_db -quiet {inst:Exponent/x_pow_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[14]} .single_bit_orig_name {x_pow[14]}
set_db -quiet {inst:Exponent/x_pow_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[14]/q} .original_name {x_pow[14]/q}
set_db -quiet {inst:Exponent/x_pow_reg[15]} .original_name {{x_pow[15]}}
set_db -quiet {inst:Exponent/x_pow_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[15]} .single_bit_orig_name {x_pow[15]}
set_db -quiet {inst:Exponent/x_pow_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[15]/q} .original_name {x_pow[15]/q}
set_db -quiet {inst:Exponent/x_pow_reg[16]} .original_name {{x_pow[16]}}
set_db -quiet {inst:Exponent/x_pow_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[16]} .single_bit_orig_name {x_pow[16]}
set_db -quiet {inst:Exponent/x_pow_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[16]/q} .original_name {x_pow[16]/q}
set_db -quiet {inst:Exponent/x_pow_reg[17]} .original_name {{x_pow[17]}}
set_db -quiet {inst:Exponent/x_pow_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[17]} .single_bit_orig_name {x_pow[17]}
set_db -quiet {inst:Exponent/x_pow_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[17]/q} .original_name {x_pow[17]/q}
set_db -quiet {inst:Exponent/x_pow_reg[18]} .original_name {{x_pow[18]}}
set_db -quiet {inst:Exponent/x_pow_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[18]} .single_bit_orig_name {x_pow[18]}
set_db -quiet {inst:Exponent/x_pow_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[18]/q} .original_name {x_pow[18]/q}
set_db -quiet {inst:Exponent/x_pow_reg[19]} .original_name {{x_pow[19]}}
set_db -quiet {inst:Exponent/x_pow_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[19]} .single_bit_orig_name {x_pow[19]}
set_db -quiet {inst:Exponent/x_pow_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[19]/q} .original_name {x_pow[19]/q}
set_db -quiet {inst:Exponent/x_pow_reg[20]} .original_name {{x_pow[20]}}
set_db -quiet {inst:Exponent/x_pow_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[20]} .single_bit_orig_name {x_pow[20]}
set_db -quiet {inst:Exponent/x_pow_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[20]/q} .original_name {x_pow[20]/q}
set_db -quiet {inst:Exponent/x_pow_reg[21]} .original_name {{x_pow[21]}}
set_db -quiet {inst:Exponent/x_pow_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[21]} .single_bit_orig_name {x_pow[21]}
set_db -quiet {inst:Exponent/x_pow_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[21]/q} .original_name {x_pow[21]/q}
set_db -quiet {inst:Exponent/x_pow_reg[22]} .original_name {{x_pow[22]}}
set_db -quiet {inst:Exponent/x_pow_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[22]} .single_bit_orig_name {x_pow[22]}
set_db -quiet {inst:Exponent/x_pow_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[22]/q} .original_name {x_pow[22]/q}
set_db -quiet {inst:Exponent/x_pow_reg[23]} .original_name {{x_pow[23]}}
set_db -quiet {inst:Exponent/x_pow_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[23]} .single_bit_orig_name {x_pow[23]}
set_db -quiet {inst:Exponent/x_pow_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[23]/q} .original_name {x_pow[23]/q}
set_db -quiet {inst:Exponent/x_pow_reg[24]} .original_name {{x_pow[24]}}
set_db -quiet {inst:Exponent/x_pow_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[24]} .single_bit_orig_name {x_pow[24]}
set_db -quiet {inst:Exponent/x_pow_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[24]/q} .original_name {x_pow[24]/q}
set_db -quiet {inst:Exponent/x_pow_reg[25]} .original_name {{x_pow[25]}}
set_db -quiet {inst:Exponent/x_pow_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[25]} .single_bit_orig_name {x_pow[25]}
set_db -quiet {inst:Exponent/x_pow_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[25]/q} .original_name {x_pow[25]/q}
set_db -quiet {inst:Exponent/x_pow_reg[26]} .original_name {{x_pow[26]}}
set_db -quiet {inst:Exponent/x_pow_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[26]} .single_bit_orig_name {x_pow[26]}
set_db -quiet {inst:Exponent/x_pow_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[26]/q} .original_name {x_pow[26]/q}
set_db -quiet {inst:Exponent/x_pow_reg[27]} .original_name {{x_pow[27]}}
set_db -quiet {inst:Exponent/x_pow_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[27]} .single_bit_orig_name {x_pow[27]}
set_db -quiet {inst:Exponent/x_pow_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[27]/q} .original_name {x_pow[27]/q}
set_db -quiet {inst:Exponent/x_pow_reg[28]} .original_name {{x_pow[28]}}
set_db -quiet {inst:Exponent/x_pow_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[28]} .single_bit_orig_name {x_pow[28]}
set_db -quiet {inst:Exponent/x_pow_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[28]/q} .original_name {x_pow[28]/q}
set_db -quiet {inst:Exponent/x_pow_reg[29]} .original_name {{x_pow[29]}}
set_db -quiet {inst:Exponent/x_pow_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[29]} .single_bit_orig_name {x_pow[29]}
set_db -quiet {inst:Exponent/x_pow_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[29]/q} .original_name {x_pow[29]/q}
set_db -quiet {inst:Exponent/x_pow_reg[30]} .original_name {{x_pow[30]}}
set_db -quiet {inst:Exponent/x_pow_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[30]} .single_bit_orig_name {x_pow[30]}
set_db -quiet {inst:Exponent/x_pow_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[30]/q} .original_name {x_pow[30]/q}
set_db -quiet {inst:Exponent/x_pow_reg[31]} .original_name {{x_pow[31]}}
set_db -quiet {inst:Exponent/x_pow_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/x_pow_reg[31]} .single_bit_orig_name {x_pow[31]}
set_db -quiet {inst:Exponent/x_pow_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/x_pow_reg[31]/q} .original_name {x_pow[31]/q}
set_db -quiet {inst:Exponent/sum_reg[0]} .original_name {{sum[0]}}
set_db -quiet {inst:Exponent/sum_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[0]} .single_bit_orig_name {sum[0]}
set_db -quiet {inst:Exponent/sum_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[0]/q} .original_name {sum[0]/q}
set_db -quiet {inst:Exponent/sum_reg[1]} .original_name {{sum[1]}}
set_db -quiet {inst:Exponent/sum_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[1]} .single_bit_orig_name {sum[1]}
set_db -quiet {inst:Exponent/sum_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[1]/q} .original_name {sum[1]/q}
set_db -quiet {inst:Exponent/sum_reg[2]} .original_name {{sum[2]}}
set_db -quiet {inst:Exponent/sum_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[2]} .single_bit_orig_name {sum[2]}
set_db -quiet {inst:Exponent/sum_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[2]/q} .original_name {sum[2]/q}
set_db -quiet {inst:Exponent/sum_reg[3]} .original_name {{sum[3]}}
set_db -quiet {inst:Exponent/sum_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[3]} .single_bit_orig_name {sum[3]}
set_db -quiet {inst:Exponent/sum_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[3]/q} .original_name {sum[3]/q}
set_db -quiet {inst:Exponent/sum_reg[4]} .original_name {{sum[4]}}
set_db -quiet {inst:Exponent/sum_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[4]} .single_bit_orig_name {sum[4]}
set_db -quiet {inst:Exponent/sum_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[4]/q} .original_name {sum[4]/q}
set_db -quiet {inst:Exponent/sum_reg[5]} .original_name {{sum[5]}}
set_db -quiet {inst:Exponent/sum_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[5]} .single_bit_orig_name {sum[5]}
set_db -quiet {inst:Exponent/sum_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[5]/q} .original_name {sum[5]/q}
set_db -quiet {inst:Exponent/sum_reg[6]} .original_name {{sum[6]}}
set_db -quiet {inst:Exponent/sum_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[6]} .single_bit_orig_name {sum[6]}
set_db -quiet {inst:Exponent/sum_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[6]/q} .original_name {sum[6]/q}
set_db -quiet {inst:Exponent/sum_reg[7]} .original_name {{sum[7]}}
set_db -quiet {inst:Exponent/sum_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[7]} .single_bit_orig_name {sum[7]}
set_db -quiet {inst:Exponent/sum_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[7]/q} .original_name {sum[7]/q}
set_db -quiet {inst:Exponent/sum_reg[8]} .original_name {{sum[8]}}
set_db -quiet {inst:Exponent/sum_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[8]} .single_bit_orig_name {sum[8]}
set_db -quiet {inst:Exponent/sum_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[8]/q} .original_name {sum[8]/q}
set_db -quiet {inst:Exponent/sum_reg[9]} .original_name {{sum[9]}}
set_db -quiet {inst:Exponent/sum_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[9]} .single_bit_orig_name {sum[9]}
set_db -quiet {inst:Exponent/sum_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[9]/q} .original_name {sum[9]/q}
set_db -quiet {inst:Exponent/sum_reg[10]} .original_name {{sum[10]}}
set_db -quiet {inst:Exponent/sum_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[10]} .single_bit_orig_name {sum[10]}
set_db -quiet {inst:Exponent/sum_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[10]/q} .original_name {sum[10]/q}
set_db -quiet {inst:Exponent/sum_reg[11]} .original_name {{sum[11]}}
set_db -quiet {inst:Exponent/sum_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[11]} .single_bit_orig_name {sum[11]}
set_db -quiet {inst:Exponent/sum_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[11]/q} .original_name {sum[11]/q}
set_db -quiet {inst:Exponent/sum_reg[12]} .original_name {{sum[12]}}
set_db -quiet {inst:Exponent/sum_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[12]} .single_bit_orig_name {sum[12]}
set_db -quiet {inst:Exponent/sum_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[12]/q} .original_name {sum[12]/q}
set_db -quiet {inst:Exponent/sum_reg[13]} .original_name {{sum[13]}}
set_db -quiet {inst:Exponent/sum_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[13]} .single_bit_orig_name {sum[13]}
set_db -quiet {inst:Exponent/sum_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[13]/q} .original_name {sum[13]/q}
set_db -quiet {inst:Exponent/sum_reg[14]} .original_name {{sum[14]}}
set_db -quiet {inst:Exponent/sum_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[14]} .single_bit_orig_name {sum[14]}
set_db -quiet {inst:Exponent/sum_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[14]/q} .original_name {sum[14]/q}
set_db -quiet {inst:Exponent/sum_reg[15]} .original_name {{sum[15]}}
set_db -quiet {inst:Exponent/sum_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[15]} .single_bit_orig_name {sum[15]}
set_db -quiet {inst:Exponent/sum_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[15]/q} .original_name {sum[15]/q}
set_db -quiet {inst:Exponent/sum_reg[16]} .original_name {{sum[16]}}
set_db -quiet {inst:Exponent/sum_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[16]} .single_bit_orig_name {sum[16]}
set_db -quiet {inst:Exponent/sum_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[16]/q} .original_name {sum[16]/q}
set_db -quiet {inst:Exponent/sum_reg[17]} .original_name {{sum[17]}}
set_db -quiet {inst:Exponent/sum_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[17]} .single_bit_orig_name {sum[17]}
set_db -quiet {inst:Exponent/sum_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[17]/q} .original_name {sum[17]/q}
set_db -quiet {inst:Exponent/sum_reg[18]} .original_name {{sum[18]}}
set_db -quiet {inst:Exponent/sum_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[18]} .single_bit_orig_name {sum[18]}
set_db -quiet {inst:Exponent/sum_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[18]/q} .original_name {sum[18]/q}
set_db -quiet {inst:Exponent/sum_reg[19]} .original_name {{sum[19]}}
set_db -quiet {inst:Exponent/sum_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[19]} .single_bit_orig_name {sum[19]}
set_db -quiet {inst:Exponent/sum_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[19]/q} .original_name {sum[19]/q}
set_db -quiet {inst:Exponent/sum_reg[20]} .original_name {{sum[20]}}
set_db -quiet {inst:Exponent/sum_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[20]} .single_bit_orig_name {sum[20]}
set_db -quiet {inst:Exponent/sum_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[20]/q} .original_name {sum[20]/q}
set_db -quiet {inst:Exponent/sum_reg[21]} .original_name {{sum[21]}}
set_db -quiet {inst:Exponent/sum_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[21]} .single_bit_orig_name {sum[21]}
set_db -quiet {inst:Exponent/sum_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[21]/q} .original_name {sum[21]/q}
set_db -quiet {inst:Exponent/sum_reg[22]} .original_name {{sum[22]}}
set_db -quiet {inst:Exponent/sum_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[22]} .single_bit_orig_name {sum[22]}
set_db -quiet {inst:Exponent/sum_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[22]/q} .original_name {sum[22]/q}
set_db -quiet {inst:Exponent/sum_reg[23]} .original_name {{sum[23]}}
set_db -quiet {inst:Exponent/sum_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[23]} .single_bit_orig_name {sum[23]}
set_db -quiet {inst:Exponent/sum_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[23]/q} .original_name {sum[23]/q}
set_db -quiet {inst:Exponent/sum_reg[24]} .original_name {{sum[24]}}
set_db -quiet {inst:Exponent/sum_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[24]} .single_bit_orig_name {sum[24]}
set_db -quiet {inst:Exponent/sum_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[24]/q} .original_name {sum[24]/q}
set_db -quiet {inst:Exponent/sum_reg[25]} .original_name {{sum[25]}}
set_db -quiet {inst:Exponent/sum_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[25]} .single_bit_orig_name {sum[25]}
set_db -quiet {inst:Exponent/sum_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[25]/q} .original_name {sum[25]/q}
set_db -quiet {inst:Exponent/sum_reg[26]} .original_name {{sum[26]}}
set_db -quiet {inst:Exponent/sum_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[26]} .single_bit_orig_name {sum[26]}
set_db -quiet {inst:Exponent/sum_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[26]/q} .original_name {sum[26]/q}
set_db -quiet {inst:Exponent/sum_reg[27]} .original_name {{sum[27]}}
set_db -quiet {inst:Exponent/sum_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[27]} .single_bit_orig_name {sum[27]}
set_db -quiet {inst:Exponent/sum_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[27]/q} .original_name {sum[27]/q}
set_db -quiet {inst:Exponent/sum_reg[28]} .original_name {{sum[28]}}
set_db -quiet {inst:Exponent/sum_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[28]} .single_bit_orig_name {sum[28]}
set_db -quiet {inst:Exponent/sum_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[28]/q} .original_name {sum[28]/q}
set_db -quiet {inst:Exponent/sum_reg[29]} .original_name {{sum[29]}}
set_db -quiet {inst:Exponent/sum_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[29]} .single_bit_orig_name {sum[29]}
set_db -quiet {inst:Exponent/sum_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[29]/q} .original_name {sum[29]/q}
set_db -quiet {inst:Exponent/sum_reg[30]} .original_name {{sum[30]}}
set_db -quiet {inst:Exponent/sum_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[30]} .single_bit_orig_name {sum[30]}
set_db -quiet {inst:Exponent/sum_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[30]/q} .original_name {sum[30]/q}
set_db -quiet {inst:Exponent/sum_reg[31]} .original_name {{sum[31]}}
set_db -quiet {inst:Exponent/sum_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[31]} .single_bit_orig_name {sum[31]}
set_db -quiet {inst:Exponent/sum_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[31]/q} .original_name {sum[31]/q}
set_db -quiet {inst:Exponent/sum_reg[32]} .original_name {{sum[32]}}
set_db -quiet {inst:Exponent/sum_reg[32]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[32]} .single_bit_orig_name {sum[32]}
set_db -quiet {inst:Exponent/sum_reg[32]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[32]/q} .original_name {sum[32]/q}
set_db -quiet {inst:Exponent/sum_reg[33]} .original_name {{sum[33]}}
set_db -quiet {inst:Exponent/sum_reg[33]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[33]} .single_bit_orig_name {sum[33]}
set_db -quiet {inst:Exponent/sum_reg[33]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[33]/q} .original_name {sum[33]/q}
set_db -quiet {inst:Exponent/sum_reg[34]} .original_name {{sum[34]}}
set_db -quiet {inst:Exponent/sum_reg[34]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[34]} .single_bit_orig_name {sum[34]}
set_db -quiet {inst:Exponent/sum_reg[34]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[34]/q} .original_name {sum[34]/q}
set_db -quiet {inst:Exponent/sum_reg[35]} .original_name {{sum[35]}}
set_db -quiet {inst:Exponent/sum_reg[35]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[35]} .single_bit_orig_name {sum[35]}
set_db -quiet {inst:Exponent/sum_reg[35]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[35]/q} .original_name {sum[35]/q}
set_db -quiet {inst:Exponent/sum_reg[36]} .original_name {{sum[36]}}
set_db -quiet {inst:Exponent/sum_reg[36]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[36]} .single_bit_orig_name {sum[36]}
set_db -quiet {inst:Exponent/sum_reg[36]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[36]/q} .original_name {sum[36]/q}
set_db -quiet {inst:Exponent/sum_reg[37]} .original_name {{sum[37]}}
set_db -quiet {inst:Exponent/sum_reg[37]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[37]} .single_bit_orig_name {sum[37]}
set_db -quiet {inst:Exponent/sum_reg[37]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[37]/q} .original_name {sum[37]/q}
set_db -quiet {inst:Exponent/sum_reg[38]} .original_name {{sum[38]}}
set_db -quiet {inst:Exponent/sum_reg[38]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[38]} .single_bit_orig_name {sum[38]}
set_db -quiet {inst:Exponent/sum_reg[38]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[38]/q} .original_name {sum[38]/q}
set_db -quiet {inst:Exponent/sum_reg[39]} .original_name {{sum[39]}}
set_db -quiet {inst:Exponent/sum_reg[39]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[39]} .single_bit_orig_name {sum[39]}
set_db -quiet {inst:Exponent/sum_reg[39]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[39]/q} .original_name {sum[39]/q}
set_db -quiet {inst:Exponent/sum_reg[40]} .original_name {{sum[40]}}
set_db -quiet {inst:Exponent/sum_reg[40]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[40]} .single_bit_orig_name {sum[40]}
set_db -quiet {inst:Exponent/sum_reg[40]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[40]/q} .original_name {sum[40]/q}
set_db -quiet {inst:Exponent/sum_reg[41]} .original_name {{sum[41]}}
set_db -quiet {inst:Exponent/sum_reg[41]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[41]} .single_bit_orig_name {sum[41]}
set_db -quiet {inst:Exponent/sum_reg[41]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[41]/q} .original_name {sum[41]/q}
set_db -quiet {inst:Exponent/sum_reg[42]} .original_name {{sum[42]}}
set_db -quiet {inst:Exponent/sum_reg[42]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[42]} .single_bit_orig_name {sum[42]}
set_db -quiet {inst:Exponent/sum_reg[42]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[42]/q} .original_name {sum[42]/q}
set_db -quiet {inst:Exponent/sum_reg[43]} .original_name {{sum[43]}}
set_db -quiet {inst:Exponent/sum_reg[43]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[43]} .single_bit_orig_name {sum[43]}
set_db -quiet {inst:Exponent/sum_reg[43]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[43]/q} .original_name {sum[43]/q}
set_db -quiet {inst:Exponent/sum_reg[44]} .original_name {{sum[44]}}
set_db -quiet {inst:Exponent/sum_reg[44]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[44]} .single_bit_orig_name {sum[44]}
set_db -quiet {inst:Exponent/sum_reg[44]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[44]/q} .original_name {sum[44]/q}
set_db -quiet {inst:Exponent/sum_reg[45]} .original_name {{sum[45]}}
set_db -quiet {inst:Exponent/sum_reg[45]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[45]} .single_bit_orig_name {sum[45]}
set_db -quiet {inst:Exponent/sum_reg[45]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[45]/q} .original_name {sum[45]/q}
set_db -quiet {inst:Exponent/sum_reg[46]} .original_name {{sum[46]}}
set_db -quiet {inst:Exponent/sum_reg[46]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[46]} .single_bit_orig_name {sum[46]}
set_db -quiet {inst:Exponent/sum_reg[46]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[46]/q} .original_name {sum[46]/q}
set_db -quiet {inst:Exponent/sum_reg[47]} .original_name {{sum[47]}}
set_db -quiet {inst:Exponent/sum_reg[47]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[47]} .single_bit_orig_name {sum[47]}
set_db -quiet {inst:Exponent/sum_reg[47]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[47]/q} .original_name {sum[47]/q}
set_db -quiet {inst:Exponent/sum_reg[48]} .original_name {{sum[48]}}
set_db -quiet {inst:Exponent/sum_reg[48]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[48]} .single_bit_orig_name {sum[48]}
set_db -quiet {inst:Exponent/sum_reg[48]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[48]/q} .original_name {sum[48]/q}
set_db -quiet {inst:Exponent/sum_reg[49]} .original_name {{sum[49]}}
set_db -quiet {inst:Exponent/sum_reg[49]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[49]} .single_bit_orig_name {sum[49]}
set_db -quiet {inst:Exponent/sum_reg[49]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[49]/q} .original_name {sum[49]/q}
set_db -quiet {inst:Exponent/sum_reg[50]} .original_name {{sum[50]}}
set_db -quiet {inst:Exponent/sum_reg[50]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[50]} .single_bit_orig_name {sum[50]}
set_db -quiet {inst:Exponent/sum_reg[50]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[50]/q} .original_name {sum[50]/q}
set_db -quiet {inst:Exponent/sum_reg[51]} .original_name {{sum[51]}}
set_db -quiet {inst:Exponent/sum_reg[51]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[51]} .single_bit_orig_name {sum[51]}
set_db -quiet {inst:Exponent/sum_reg[51]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[51]/q} .original_name {sum[51]/q}
set_db -quiet {inst:Exponent/sum_reg[52]} .original_name {{sum[52]}}
set_db -quiet {inst:Exponent/sum_reg[52]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[52]} .single_bit_orig_name {sum[52]}
set_db -quiet {inst:Exponent/sum_reg[52]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[52]/q} .original_name {sum[52]/q}
set_db -quiet {inst:Exponent/sum_reg[53]} .original_name {{sum[53]}}
set_db -quiet {inst:Exponent/sum_reg[53]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[53]} .single_bit_orig_name {sum[53]}
set_db -quiet {inst:Exponent/sum_reg[53]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[53]/q} .original_name {sum[53]/q}
set_db -quiet {inst:Exponent/sum_reg[54]} .original_name {{sum[54]}}
set_db -quiet {inst:Exponent/sum_reg[54]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[54]} .single_bit_orig_name {sum[54]}
set_db -quiet {inst:Exponent/sum_reg[54]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[54]/q} .original_name {sum[54]/q}
set_db -quiet {inst:Exponent/sum_reg[55]} .original_name {{sum[55]}}
set_db -quiet {inst:Exponent/sum_reg[55]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[55]} .single_bit_orig_name {sum[55]}
set_db -quiet {inst:Exponent/sum_reg[55]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[55]/q} .original_name {sum[55]/q}
set_db -quiet {inst:Exponent/sum_reg[56]} .original_name {{sum[56]}}
set_db -quiet {inst:Exponent/sum_reg[56]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[56]} .single_bit_orig_name {sum[56]}
set_db -quiet {inst:Exponent/sum_reg[56]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[56]/q} .original_name {sum[56]/q}
set_db -quiet {inst:Exponent/sum_reg[57]} .original_name {{sum[57]}}
set_db -quiet {inst:Exponent/sum_reg[57]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[57]} .single_bit_orig_name {sum[57]}
set_db -quiet {inst:Exponent/sum_reg[57]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[57]/q} .original_name {sum[57]/q}
set_db -quiet {inst:Exponent/sum_reg[58]} .original_name {{sum[58]}}
set_db -quiet {inst:Exponent/sum_reg[58]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[58]} .single_bit_orig_name {sum[58]}
set_db -quiet {inst:Exponent/sum_reg[58]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[58]/q} .original_name {sum[58]/q}
set_db -quiet {inst:Exponent/sum_reg[59]} .original_name {{sum[59]}}
set_db -quiet {inst:Exponent/sum_reg[59]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[59]} .single_bit_orig_name {sum[59]}
set_db -quiet {inst:Exponent/sum_reg[59]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[59]/q} .original_name {sum[59]/q}
set_db -quiet {inst:Exponent/sum_reg[60]} .original_name {{sum[60]}}
set_db -quiet {inst:Exponent/sum_reg[60]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[60]} .single_bit_orig_name {sum[60]}
set_db -quiet {inst:Exponent/sum_reg[60]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[60]/q} .original_name {sum[60]/q}
set_db -quiet {inst:Exponent/sum_reg[61]} .original_name {{sum[61]}}
set_db -quiet {inst:Exponent/sum_reg[61]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[61]} .single_bit_orig_name {sum[61]}
set_db -quiet {inst:Exponent/sum_reg[61]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[61]/q} .original_name {sum[61]/q}
set_db -quiet {inst:Exponent/sum_reg[62]} .original_name {{sum[62]}}
set_db -quiet {inst:Exponent/sum_reg[62]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[62]} .single_bit_orig_name {sum[62]}
set_db -quiet {inst:Exponent/sum_reg[62]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[62]/q} .original_name {sum[62]/q}
set_db -quiet {inst:Exponent/sum_reg[63]} .original_name {{sum[63]}}
set_db -quiet {inst:Exponent/sum_reg[63]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/sum_reg[63]} .single_bit_orig_name {sum[63]}
set_db -quiet {inst:Exponent/sum_reg[63]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/sum_reg[63]/q} .original_name {sum[63]/q}
set_db -quiet {inst:Exponent/div_counter_reg[0]} .original_name {{div_counter[0]}}
set_db -quiet {inst:Exponent/div_counter_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[0]} .single_bit_orig_name {div_counter[0]}
set_db -quiet {inst:Exponent/div_counter_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[0]/q} .original_name {div_counter[0]/q}
set_db -quiet {inst:Exponent/div_counter_reg[1]} .original_name {{div_counter[1]}}
set_db -quiet {inst:Exponent/div_counter_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[1]} .single_bit_orig_name {div_counter[1]}
set_db -quiet {inst:Exponent/div_counter_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[1]/q} .original_name {div_counter[1]/q}
set_db -quiet {inst:Exponent/div_counter_reg[2]} .original_name {{div_counter[2]}}
set_db -quiet {inst:Exponent/div_counter_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[2]} .single_bit_orig_name {div_counter[2]}
set_db -quiet {inst:Exponent/div_counter_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[2]/q} .original_name {div_counter[2]/q}
set_db -quiet {inst:Exponent/div_counter_reg[3]} .original_name {{div_counter[3]}}
set_db -quiet {inst:Exponent/div_counter_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[3]} .single_bit_orig_name {div_counter[3]}
set_db -quiet {inst:Exponent/div_counter_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[3]/q} .original_name {div_counter[3]/q}
set_db -quiet {inst:Exponent/div_counter_reg[4]} .original_name {{div_counter[4]}}
set_db -quiet {inst:Exponent/div_counter_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[4]} .single_bit_orig_name {div_counter[4]}
set_db -quiet {inst:Exponent/div_counter_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[4]/q} .original_name {div_counter[4]/q}
set_db -quiet {inst:Exponent/div_counter_reg[5]} .original_name {{div_counter[5]}}
set_db -quiet {inst:Exponent/div_counter_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[5]} .single_bit_orig_name {div_counter[5]}
set_db -quiet {inst:Exponent/div_counter_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[5]/q} .original_name {div_counter[5]/q}
set_db -quiet {inst:Exponent/div_counter_reg[6]} .original_name {{div_counter[6]}}
set_db -quiet {inst:Exponent/div_counter_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[6]} .single_bit_orig_name {div_counter[6]}
set_db -quiet {inst:Exponent/div_counter_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[6]/q} .original_name {div_counter[6]/q}
set_db -quiet {inst:Exponent/div_counter_reg[7]} .original_name {{div_counter[7]}}
set_db -quiet {inst:Exponent/div_counter_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[7]} .single_bit_orig_name {div_counter[7]}
set_db -quiet {inst:Exponent/div_counter_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[7]/q} .original_name {div_counter[7]/q}
set_db -quiet {inst:Exponent/div_counter_reg[8]} .original_name {{div_counter[8]}}
set_db -quiet {inst:Exponent/div_counter_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[8]} .single_bit_orig_name {div_counter[8]}
set_db -quiet {inst:Exponent/div_counter_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[8]/q} .original_name {div_counter[8]/q}
set_db -quiet {inst:Exponent/div_counter_reg[9]} .original_name {{div_counter[9]}}
set_db -quiet {inst:Exponent/div_counter_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[9]} .single_bit_orig_name {div_counter[9]}
set_db -quiet {inst:Exponent/div_counter_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[9]/q} .original_name {div_counter[9]/q}
set_db -quiet {inst:Exponent/div_counter_reg[10]} .original_name {{div_counter[10]}}
set_db -quiet {inst:Exponent/div_counter_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[10]} .single_bit_orig_name {div_counter[10]}
set_db -quiet {inst:Exponent/div_counter_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[10]/q} .original_name {div_counter[10]/q}
set_db -quiet {inst:Exponent/div_counter_reg[11]} .original_name {{div_counter[11]}}
set_db -quiet {inst:Exponent/div_counter_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[11]} .single_bit_orig_name {div_counter[11]}
set_db -quiet {inst:Exponent/div_counter_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[11]/q} .original_name {div_counter[11]/q}
set_db -quiet {inst:Exponent/div_counter_reg[12]} .original_name {{div_counter[12]}}
set_db -quiet {inst:Exponent/div_counter_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[12]} .single_bit_orig_name {div_counter[12]}
set_db -quiet {inst:Exponent/div_counter_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[12]/q} .original_name {div_counter[12]/q}
set_db -quiet {inst:Exponent/div_counter_reg[13]} .original_name {{div_counter[13]}}
set_db -quiet {inst:Exponent/div_counter_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[13]} .single_bit_orig_name {div_counter[13]}
set_db -quiet {inst:Exponent/div_counter_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[13]/q} .original_name {div_counter[13]/q}
set_db -quiet {inst:Exponent/div_counter_reg[14]} .original_name {{div_counter[14]}}
set_db -quiet {inst:Exponent/div_counter_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[14]} .single_bit_orig_name {div_counter[14]}
set_db -quiet {inst:Exponent/div_counter_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[14]/q} .original_name {div_counter[14]/q}
set_db -quiet {inst:Exponent/div_counter_reg[15]} .original_name {{div_counter[15]}}
set_db -quiet {inst:Exponent/div_counter_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[15]} .single_bit_orig_name {div_counter[15]}
set_db -quiet {inst:Exponent/div_counter_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[15]/q} .original_name {div_counter[15]/q}
set_db -quiet {inst:Exponent/div_counter_reg[16]} .original_name {{div_counter[16]}}
set_db -quiet {inst:Exponent/div_counter_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[16]} .single_bit_orig_name {div_counter[16]}
set_db -quiet {inst:Exponent/div_counter_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[16]/q} .original_name {div_counter[16]/q}
set_db -quiet {inst:Exponent/div_counter_reg[17]} .original_name {{div_counter[17]}}
set_db -quiet {inst:Exponent/div_counter_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[17]} .single_bit_orig_name {div_counter[17]}
set_db -quiet {inst:Exponent/div_counter_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[17]/q} .original_name {div_counter[17]/q}
set_db -quiet {inst:Exponent/div_counter_reg[18]} .original_name {{div_counter[18]}}
set_db -quiet {inst:Exponent/div_counter_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[18]} .single_bit_orig_name {div_counter[18]}
set_db -quiet {inst:Exponent/div_counter_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[18]/q} .original_name {div_counter[18]/q}
set_db -quiet {inst:Exponent/div_counter_reg[19]} .original_name {{div_counter[19]}}
set_db -quiet {inst:Exponent/div_counter_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[19]} .single_bit_orig_name {div_counter[19]}
set_db -quiet {inst:Exponent/div_counter_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[19]/q} .original_name {div_counter[19]/q}
set_db -quiet {inst:Exponent/div_counter_reg[20]} .original_name {{div_counter[20]}}
set_db -quiet {inst:Exponent/div_counter_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[20]} .single_bit_orig_name {div_counter[20]}
set_db -quiet {inst:Exponent/div_counter_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[20]/q} .original_name {div_counter[20]/q}
set_db -quiet {inst:Exponent/div_counter_reg[21]} .original_name {{div_counter[21]}}
set_db -quiet {inst:Exponent/div_counter_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[21]} .single_bit_orig_name {div_counter[21]}
set_db -quiet {inst:Exponent/div_counter_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[21]/q} .original_name {div_counter[21]/q}
set_db -quiet {inst:Exponent/div_counter_reg[22]} .original_name {{div_counter[22]}}
set_db -quiet {inst:Exponent/div_counter_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[22]} .single_bit_orig_name {div_counter[22]}
set_db -quiet {inst:Exponent/div_counter_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[22]/q} .original_name {div_counter[22]/q}
set_db -quiet {inst:Exponent/div_counter_reg[23]} .original_name {{div_counter[23]}}
set_db -quiet {inst:Exponent/div_counter_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[23]} .single_bit_orig_name {div_counter[23]}
set_db -quiet {inst:Exponent/div_counter_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[23]/q} .original_name {div_counter[23]/q}
set_db -quiet {inst:Exponent/div_counter_reg[24]} .original_name {{div_counter[24]}}
set_db -quiet {inst:Exponent/div_counter_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[24]} .single_bit_orig_name {div_counter[24]}
set_db -quiet {inst:Exponent/div_counter_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[24]/q} .original_name {div_counter[24]/q}
set_db -quiet {inst:Exponent/div_counter_reg[25]} .original_name {{div_counter[25]}}
set_db -quiet {inst:Exponent/div_counter_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[25]} .single_bit_orig_name {div_counter[25]}
set_db -quiet {inst:Exponent/div_counter_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[25]/q} .original_name {div_counter[25]/q}
set_db -quiet {inst:Exponent/div_counter_reg[26]} .original_name {{div_counter[26]}}
set_db -quiet {inst:Exponent/div_counter_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[26]} .single_bit_orig_name {div_counter[26]}
set_db -quiet {inst:Exponent/div_counter_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[26]/q} .original_name {div_counter[26]/q}
set_db -quiet {inst:Exponent/div_counter_reg[27]} .original_name {{div_counter[27]}}
set_db -quiet {inst:Exponent/div_counter_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[27]} .single_bit_orig_name {div_counter[27]}
set_db -quiet {inst:Exponent/div_counter_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[27]/q} .original_name {div_counter[27]/q}
set_db -quiet {inst:Exponent/div_counter_reg[28]} .original_name {{div_counter[28]}}
set_db -quiet {inst:Exponent/div_counter_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[28]} .single_bit_orig_name {div_counter[28]}
set_db -quiet {inst:Exponent/div_counter_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[28]/q} .original_name {div_counter[28]/q}
set_db -quiet {inst:Exponent/div_counter_reg[29]} .original_name {{div_counter[29]}}
set_db -quiet {inst:Exponent/div_counter_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[29]} .single_bit_orig_name {div_counter[29]}
set_db -quiet {inst:Exponent/div_counter_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[29]/q} .original_name {div_counter[29]/q}
set_db -quiet {inst:Exponent/div_counter_reg[30]} .original_name {{div_counter[30]}}
set_db -quiet {inst:Exponent/div_counter_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[30]} .single_bit_orig_name {div_counter[30]}
set_db -quiet {inst:Exponent/div_counter_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[30]/q} .original_name {div_counter[30]/q}
set_db -quiet {inst:Exponent/div_counter_reg[31]} .original_name {{div_counter[31]}}
set_db -quiet {inst:Exponent/div_counter_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:Exponent/div_counter_reg[31]} .single_bit_orig_name {div_counter[31]}
set_db -quiet {inst:Exponent/div_counter_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:Exponent/div_counter_reg[31]/q} .original_name {div_counter[31]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN GLO TBR TABLE
set_db -quiet design:Exponent .set_boundary_change_new {start restore}
set_db -quiet design:Exponent .set_boundary_change_new {finish restore}
# END GLO TBR TABLE
set_db -quiet hinst:Exponent/div .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 66 30}}
set_db -quiet hinst:Exponent/div/eq_44_23 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 44 23}}
set_db -quiet hinst:Exponent/div/gte_22_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 22 17}}
set_db -quiet hinst:Exponent/div/sub_23_28 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 28}}
set_db -quiet hinst:Exponent/div/add_62_28 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 62 28}}
set_db -quiet inst:Exponent/div/g13 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g14 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 44 23}}
set_db -quiet hinst:Exponent/div/mux_busy_44_23 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 44 23}}
set_db -quiet inst:Exponent/div/g15 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 55 23}}
set_db -quiet hinst:Exponent/div/mux_i_41_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet hinst:Exponent/div/mux_dbz_44_23 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 44 23}}
set_db -quiet hinst:Exponent/div/mux_done_44_23 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 44 23}}
set_db -quiet hinst:Exponent/div/mux_done_55_23 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 55 23}}
set_db -quiet hinst:Exponent/div/mux_done_54_26 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 54 26}}
set_db -quiet hinst:Exponent/div/mux_done_41_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet hinst:Exponent/div/mux_busy_41_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet hinst:Exponent/div/mux_quo_next_22_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 22 17}}
set_db -quiet hinst:Exponent/div/mux_quo_41_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet hinst:Exponent/div/mux_acc_next_22_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 22 17}}
set_db -quiet hinst:Exponent/div/mux_acc_41_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g18 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 54 26}}
set_db -quiet inst:Exponent/div/g19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g20 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g26 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g27 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 32 13}}
set_db -quiet inst:Exponent/div/g29 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 54 26}}
set_db -quiet inst:Exponent/div/g30 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g31 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g32 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 32 13}}
set_db -quiet inst:Exponent/div/g40 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 41 17}}
set_db -quiet inst:Exponent/div/g41 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 32 13}}
set_db -quiet inst:Exponent/div/g1 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 32 13}}
set_db -quiet inst:Exponent/div/busy_reg .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 54 26}}
set_db -quiet inst:Exponent/div/done_reg .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 6 23}}
set_db -quiet inst:Exponent/div/valid_reg .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 7 24}}
set_db -quiet inst:Exponent/div/dbz_reg .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 8 22}}
set_db -quiet {inst:Exponent/div/val_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/val_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 11 35}}
set_db -quiet {inst:Exponent/div/rem_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/rem_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 13 5}}
set_db -quiet {inst:Exponent/div/b1_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/b1_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 23 30}}
set_db -quiet {inst:Exponent/div/quo_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/quo_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 42}}
set_db -quiet {inst:Exponent/div/acc_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/acc_reg[32]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 26 37}}
set_db -quiet {inst:Exponent/div/i_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 62 26}}
set_db -quiet {inst:Exponent/div/i_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 62 26}}
set_db -quiet {inst:Exponent/div/i_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 62 26}}
set_db -quiet {inst:Exponent/div/i_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 62 26}}
set_db -quiet {inst:Exponent/div/i_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 62 26}}
set_db -quiet inst:Exponent/div/g208 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 55 23}}
set_db -quiet inst:Exponent/div/g209 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 55 23}}
set_db -quiet inst:Exponent/div/g210 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/div.sv 55 23}}
set_db -quiet hinst:Exponent/eq_52_39 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 52 39}}
set_db -quiet hinst:Exponent/add_120_63 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 63}}
set_db -quiet hinst:Exponent/mul_80_28 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 28}}
set_db -quiet hinst:Exponent/add_108_32 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 32}}
set_db -quiet hinst:Exponent/add_118_48 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 118 48}}
set_db -quiet hinst:Exponent/mux_46_28 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 46 28}}
set_db -quiet hinst:Exponent/mux_50_27 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 50 27}}
set_db -quiet hinst:Exponent/mux_52_39 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 52 39}}
set_db -quiet hinst:Exponent/ctl_states_45_13 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 45 13}}
set_db -quiet hinst:Exponent/mux_nxt_states_45_13 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 45 13}}
set_db -quiet hinst:Exponent/mux_nxt_states_45_17 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 45 13}}
set_db -quiet hinst:Exponent/ctl_states_96_19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet hinst:Exponent/mux_div_counter_96_19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet hinst:Exponent/mux_sum_96_19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet hinst:Exponent/mux_119_42 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 119 42}}
set_db -quiet hinst:Exponent/mux_done_96_19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet hinst:Exponent/mux_101_30 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 101 30}}
set_db -quiet hinst:Exponent/mux_120_46 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 46}}
set_db -quiet hinst:Exponent/mux_div_start_96_19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet hinst:Exponent/mux_x2_96_19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet inst:Exponent/g18 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet inst:Exponent/g19 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet inst:Exponent/g20 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g21 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g22 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g23 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g24 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g25 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g26 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g27 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g28 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g29 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g30 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g31 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g32 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g33 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g34 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g35 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g36 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g37 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g38 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g39 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g40 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g41 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g42 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g43 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g44 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g45 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g46 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g47 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g48 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g49 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g50 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g51 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 10 38}}
set_db -quiet inst:Exponent/g52 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g53 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g54 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g55 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g56 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g57 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g58 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g59 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g60 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g61 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g62 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g63 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g64 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g65 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g66 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g67 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g68 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g69 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g70 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g71 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g72 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g73 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g74 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g75 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g76 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g77 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g78 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g79 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g80 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g81 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g82 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g83 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g84 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g85 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g86 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g87 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g88 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g89 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g90 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g91 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g92 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g93 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g94 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g95 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g96 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g97 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g98 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g99 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g100 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g101 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g102 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g103 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g104 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g105 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g106 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g107 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g108 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g109 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g110 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g111 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g112 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g113 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g114 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g115 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet inst:Exponent/g181 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 96 19}}
set_db -quiet inst:Exponent/g1 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 50 27}}
set_db -quiet inst:Exponent/g183 .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 84 13}}
set_db -quiet {inst:Exponent/states_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 45 13}}
set_db -quiet {inst:Exponent/states_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 45 13}}
set_db -quiet {inst:Exponent/data_out_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[32]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[33]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[34]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[35]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[36]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[37]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[38]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[39]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[40]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[41]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[42]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[43]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[44]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[45]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[46]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[47]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[48]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[49]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[50]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[51]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[52]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[53]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[54]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[55]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[56]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[57]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[58]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[59]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[60]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[61]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[62]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet {inst:Exponent/data_out_reg[63]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 75}}
set_db -quiet inst:Exponent/busy_reg .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 12 20}}
set_db -quiet inst:Exponent/done_reg .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 14 1}}
set_db -quiet inst:Exponent/div_start_reg .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 69 16}}
set_db -quiet {inst:Exponent/dinput_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/dinput_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 80 30}}
set_db -quiet {inst:Exponent/x2_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x2_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 108 34}}
set_db -quiet {inst:Exponent/x_pow_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/x_pow_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 74 12}}
set_db -quiet {inst:Exponent/sum_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[32]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[33]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[34]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[35]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[36]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[37]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[38]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[39]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[40]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[41]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[42]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[43]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[44]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[45]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[46]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[47]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[48]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[49]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[50]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[51]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[52]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[53]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[54]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[55]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[56]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[57]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[58]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[59]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[60]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[61]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[62]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/sum_reg[63]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 59}}
set_db -quiet {inst:Exponent/div_counter_reg[0]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[1]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[2]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[3]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[4]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[5]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[6]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[7]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[8]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[9]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[10]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[11]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[12]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[13]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[14]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[15]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[16]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[17]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[18]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[19]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[20]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[21]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[22]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[23]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[24]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[25]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[26]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[27]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[28]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[29]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[30]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
set_db -quiet {inst:Exponent/div_counter_reg[31]} .file_row_col {{/data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../src/rtl/tsexp.v 120 34}}
# there is no file_row_col attribute information available
set_db -quiet source_verbose true
#############################################################
#####   FLOW WRITE   ########################################
##
## Written by Genus(TM) Synthesis Solution version 21.15-s080_1
## flowkit v21.12-s013_1
## Written on 19:18:18 24-Oct 2023
#############################################################
#####   Flow Definitions   ##################################

#############################################################
#####   Step Definitions   ##################################


#############################################################
#####   Attribute Definitions   #############################

if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}


#############################################################
#####   Flow History   ######################################

if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}
if {[is_attribute flow_plugin_steps -obj_type root]} {set_db flow_plugin_steps {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_remark -obj_type root]} {set_db flow_remark {}}
if {[is_attribute flow_features -obj_type root]} {set_db flow_features {}}
if {[is_attribute flow_feature_values -obj_type root]} {set_db flow_feature_values {}}
if {[is_attribute flow_write_db_args -obj_type root]} {set_db flow_write_db_args {}}
if {[is_attribute flow_write_db_sdc -obj_type root]} {set_db flow_write_db_sdc true}
if {[is_attribute flow_write_db_common -obj_type root]} {set_db flow_write_db_common false}
if {[is_attribute flow_post_db_overwrite -obj_type root]} {set_db flow_post_db_overwrite {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_last -obj_type root]} {set_db flow_step_last {}}
if {[is_attribute flow_step_current -obj_type root]} {set_db flow_step_current {}}
if {[is_attribute flow_step_canonical_current -obj_type root]} {set_db flow_step_canonical_current {}}
if {[is_attribute flow_step_next -obj_type root]} {set_db flow_step_next {}}
if {[is_attribute flow_working_directory -obj_type root]} {set_db flow_working_directory .}
if {[is_attribute flow_branch -obj_type root]} {set_db flow_branch {}}
if {[is_attribute flow_caller_data -obj_type root]} {set_db flow_caller_data {}}
if {[is_attribute flow_metrics_snapshot_uuid -obj_type root]} {set_db flow_metrics_snapshot_uuid e367cd02-eeb9-44fb-859e-917654a7dd06}
if {[is_attribute flow_starting_db -obj_type root]} {set_db flow_starting_db {}}
if {[is_attribute flow_db_directory -obj_type root]} {set_db flow_db_directory dbs}
if {[is_attribute flow_report_directory -obj_type root]} {set_db flow_report_directory reports}
if {[is_attribute flow_log_directory -obj_type root]} {set_db flow_log_directory logs}
if {[is_attribute flow_mail_to -obj_type root]} {set_db flow_mail_to {}}
if {[is_attribute flow_exit_when_done -obj_type root]} {set_db flow_exit_when_done false}
if {[is_attribute flow_mail_on_error -obj_type root]} {set_db flow_mail_on_error false}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_history -obj_type root]} {set_db flow_history {}}
if {[is_attribute flow_step_last_status -obj_type root]} {set_db flow_step_last_status not_run}
if {[is_attribute flow_step_last_msg -obj_type root]} {set_db flow_step_last_msg {}}
if {[is_attribute flow_run_tag -obj_type root]} {set_db flow_run_tag {}}
if {[is_attribute flow_current_cache -obj_type root]} {set_db flow_current_cache {}}
if {[is_attribute flow_step_order_cache -obj_type root]} {set_db flow_step_order_cache {}}
if {[is_attribute flow_step_results_cache -obj_type root]} {set_db flow_step_results_cache {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_execute_in_global -obj_type root]} {set_db flow_execute_in_global true}
if {[is_attribute flow_overwrite_db -obj_type root]} {set_db flow_overwrite_db false}
if {[is_attribute flow_print_run_information -obj_type root]} {set_db flow_print_run_information false}
if {[is_attribute flow_verbose -obj_type root]} {set_db flow_verbose true}
if {[is_attribute flow_print_run_information_full -obj_type root]} {set_db flow_print_run_information_full false}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_init_header_tcl -obj_type root]} {set_db flow_init_header_tcl {}}
if {[is_attribute flow_init_footer_tcl -obj_type root]} {set_db flow_init_footer_tcl {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_step_last_number -obj_type root]} {set_db flow_step_last_number 0}
if {[is_attribute flow_autoload_applets -obj_type root]} {set_db flow_autoload_applets false}
if {[is_attribute flow_autoload_dir -obj_type root]} {set_db flow_autoload_dir error}
if {[is_attribute flow_skip_auto_db_save -obj_type root]} {set_db flow_skip_auto_db_save true}
if {[is_attribute flow_skip_auto_generate_metrics -obj_type root]} {set_db flow_skip_auto_generate_metrics false}
if {[is_attribute flow_top -obj_type root]} {set_db flow_top {}}
if {[is_attribute flow_hier_path -obj_type root]} {set_db flow_hier_path {}}
if {[is_attribute flow_schedule -obj_type root]} {set_db flow_schedule {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_script -obj_type root]} {set_db flow_script {}}
if {[is_attribute flow_yaml_script -obj_type root]} {set_db flow_yaml_script {}}
if {[is_attribute flow_cla_enabled_features -obj_type root]} {set_db flow_cla_enabled_features {}}
if {[is_attribute flow_cla_inject_tcl -obj_type root]} {set_db flow_cla_inject_tcl {}}
if {[is_attribute flow_error_message -obj_type root]} {set_db flow_error_message {}}
if {[is_attribute flow_error_errorinfo -obj_type root]} {set_db flow_error_errorinfo {}}
if {[is_attribute flow_exclude_time_for_init_flow -obj_type root]} {set_db flow_exclude_time_for_init_flow false}
if {[is_attribute flow_error_write_db -obj_type root]} {set_db flow_error_write_db true}
if {[is_attribute flow_advanced_metric_isolation -obj_type root]} {set_db flow_advanced_metric_isolation flow}
if {[is_attribute flow_yaml_root -obj_type root]} {set_db flow_yaml_root {}}
if {[is_attribute flow_yaml_root_dir -obj_type root]} {set_db flow_yaml_root_dir {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}

#############################################################
#####   User Defined Attributes   ###########################

