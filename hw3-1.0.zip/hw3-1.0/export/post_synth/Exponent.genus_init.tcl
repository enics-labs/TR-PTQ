################################################################################
#
# Init setup file
# Created by Genus(TM) Synthesis Solution on 10/24/2023 19:24:06
#
################################################################################
if { ![is_common_ui_mode] } { error "ERROR: This script requires common_ui to be active."}

read_netlist /data/project/tsmc65/users/levyeli6/ws/DVD2024/exponent/workspace/../export/post_synth/Exponent.v

init_design -skip_sdc_read
