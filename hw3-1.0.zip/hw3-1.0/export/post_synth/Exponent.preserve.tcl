################################################################################
#       Setting dont_touch and dont_use preserve setting
################################################################################
catch {set_db hinst:Exponent/RC_CG_HIER_INST0 .dont_touch_hports true}
catch {set_db hinst:Exponent/RC_CG_HIER_INST1 .dont_touch_hports true}
catch {set_db hinst:Exponent/RC_CG_HIER_INST2 .dont_touch_hports true}
catch {set_db hinst:Exponent/RC_CG_HIER_INST3 .dont_touch_hports true}
catch {set_db hinst:Exponent/RC_CG_HIER_INST4 .dont_touch_hports true}
catch {set_db hinst:Exponent/div/RC_CG_HIER_INST5 .dont_touch_hports true}
catch {set_db hinst:Exponent/div/RC_CG_HIER_INST6 .dont_touch_hports true}
catch {set_db hinst:Exponent/div/RC_CG_HIER_INST7 .dont_touch_hports true}
